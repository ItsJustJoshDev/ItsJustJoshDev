.class public final Lcpt;
.super Ljava/lang/Object;
.source "PG"


# instance fields
.field public final a:Lcpr;

.field protected b:Z

.field public c:Ljava/util/ArrayList;

.field public d:Ljava/util/ArrayList;

.field public e:Ljava/util/ArrayList;

.field public f:Ljava/util/Set;

.field public g:Ljava/lang/String;

.field public h:Ljava/lang/String;

.field public final i:Lcpz;

.field public final j:Lfcy;

.field public k:Z

.field public final l:Lfiz;

.field public m:Ldal;

.field public final n:Lfht;


# direct methods
.method public constructor <init>(Lcpv;Lfiz;)V
    .locals 8

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 2
    .line 3
    .line 4
    sget-object v0, Lflg;->a:Lflg;

    .line 5
    .line 6
    invoke-virtual {v0}, Lfhw;->o()Lfhr;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    check-cast v0, Lfht;

    .line 11
    .line 12
    iput-object v0, p0, Lcpt;->n:Lfht;

    .line 13
    .line 14
    const/4 v1, 0x0

    .line 15
    iput-boolean v1, p0, Lcpt;->b:Z

    .line 16
    .line 17
    const/4 v2, 0x0

    .line 18
    iput-object v2, p0, Lcpt;->c:Ljava/util/ArrayList;

    .line 19
    .line 20
    iput-object v2, p0, Lcpt;->d:Ljava/util/ArrayList;

    .line 21
    .line 22
    iput-object v2, p0, Lcpt;->e:Ljava/util/ArrayList;

    .line 23
    .line 24
    iput-boolean v1, p0, Lcpt;->k:Z

    .line 25
    .line 26
    iput-object p1, p0, Lcpt;->a:Lcpr;

    .line 27
    .line 28
    iget-object v1, p1, Lcpr;->h:Ljava/lang/String;

    .line 29
    .line 30
    iput-object v1, p0, Lcpt;->h:Ljava/lang/String;

    .line 31
    .line 32
    iget-object v1, p1, Lcpr;->e:Ljava/lang/String;

    .line 33
    .line 34
    iput-object v1, p0, Lcpt;->g:Ljava/lang/String;

    .line 35
    .line 36
    iget-object v1, p1, Lcpr;->f:Landroid/content/Context;

    .line 37
    .line 38
    invoke-virtual {v1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 39
    .line 40
    .line 41
    move-result-object v1

    .line 42
    instance-of v1, v1, Lcpx;

    .line 43
    .line 44
    if-eqz v1, :cond_0

    .line 45
    .line 46
    iget-object v1, p1, Lcpr;->f:Landroid/content/Context;

    .line 47
    .line 48
    invoke-virtual {v1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    .line 49
    .line 50
    .line 51
    move-result-object v1

    .line 52
    check-cast v1, Lcpx;

    .line 53
    .line 54
    goto :goto_0

    .line 55
    :cond_0
    sget-object v1, Lcpy;->a:Ljava/util/concurrent/atomic/AtomicReference;

    .line 56
    .line 57
    invoke-virtual {v1}, Ljava/util/concurrent/atomic/AtomicReference;->get()Ljava/lang/Object;

    .line 58
    .line 59
    .line 60
    move-result-object v1

    .line 61
    check-cast v1, Lcpx;

    .line 62
    .line 63
    :goto_0
    if-eqz v1, :cond_1

    .line 64
    .line 65
    invoke-interface {v1}, Lcpx;->a()Lcpz;

    .line 66
    .line 67
    .line 68
    move-result-object v3

    .line 69
    goto :goto_1

    .line 70
    :cond_1
    move-object v3, v2

    .line 71
    :goto_1
    if-nez v3, :cond_2

    .line 72
    .line 73
    iput-object v2, p0, Lcpt;->i:Lcpz;

    .line 74
    .line 75
    goto :goto_3

    .line 76
    :cond_2
    iget-object v4, v3, Lcpz;->b:Lflh;

    .line 77
    .line 78
    sget-object v5, Lflh;->b:Lflh;

    .line 79
    .line 80
    if-eq v4, v5, :cond_4

    .line 81
    .line 82
    sget-object v6, Lflh;->c:Lflh;

    .line 83
    .line 84
    if-ne v4, v6, :cond_3

    .line 85
    .line 86
    goto :goto_2

    .line 87
    :cond_3
    invoke-virtual {v4}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 88
    .line 89
    .line 90
    move-result-object v3

    .line 91
    invoke-static {v5}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    .line 92
    .line 93
    .line 94
    move-result-object v4

    .line 95
    invoke-static {v6}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    .line 96
    .line 97
    .line 98
    move-result-object v5

    .line 99
    new-instance v6, Ljava/lang/StringBuilder;

    .line 100
    .line 101
    const-string v7, "The provided ProductIdOrigin "

    .line 102
    .line 103
    invoke-direct {v6, v7}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 104
    .line 105
    .line 106
    invoke-virtual {v6, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 107
    .line 108
    .line 109
    const-string v3, " is not one of the process-level expected values: "

    .line 110
    .line 111
    invoke-virtual {v6, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 112
    .line 113
    .line 114
    invoke-virtual {v6, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 115
    .line 116
    .line 117
    const-string v3, " or "

    .line 118
    .line 119
    invoke-virtual {v6, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 120
    .line 121
    .line 122
    invoke-virtual {v6, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 123
    .line 124
    .line 125
    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 126
    .line 127
    .line 128
    move-result-object v3

    .line 129
    const-string v4, "AbstractLogEventBuilder"

    .line 130
    .line 131
    invoke-static {v4, v3}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 132
    .line 133
    .line 134
    iput-object v2, p0, Lcpt;->i:Lcpz;

    .line 135
    .line 136
    goto :goto_3

    .line 137
    :cond_4
    :goto_2
    iput-object v3, p0, Lcpt;->i:Lcpz;

    .line 138
    .line 139
    :goto_3
    if-eqz v1, :cond_5

    .line 140
    .line 141
    invoke-interface {v1}, Lcpx;->b()Lfcy;

    .line 142
    .line 143
    .line 144
    move-result-object v2

    .line 145
    :cond_5
    iput-object v2, p0, Lcpt;->j:Lfcy;

    .line 146
    .line 147
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    .line 148
    .line 149
    .line 150
    move-result-wide v1

    .line 151
    iget-object v3, v0, Lfhr;->b:Lfhw;

    .line 152
    .line 153
    invoke-virtual {v3}, Lfhw;->z()Z

    .line 154
    .line 155
    .line 156
    move-result v3

    .line 157
    if-nez v3, :cond_6

    .line 158
    .line 159
    invoke-virtual {v0}, Lfhr;->l()V

    .line 160
    .line 161
    .line 162
    :cond_6
    iget-object v3, v0, Lfht;->b:Lfhw;

    .line 163
    .line 164
    check-cast v3, Lflg;

    .line 165
    .line 166
    iget v4, v3, Lflg;->b:I

    .line 167
    .line 168
    const/4 v5, 0x1

    .line 169
    or-int/2addr v4, v5

    .line 170
    iput v4, v3, Lflg;->b:I

    .line 171
    .line 172
    iput-wide v1, v3, Lflg;->c:J

    .line 173
    .line 174
    iget-object v1, v0, Lfht;->b:Lfhw;

    .line 175
    .line 176
    check-cast v1, Lflg;

    .line 177
    .line 178
    iget-wide v1, v1, Lflg;->c:J

    .line 179
    .line 180
    sget-object v3, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    .line 181
    .line 182
    invoke-static {}, Ljava/util/TimeZone;->getDefault()Ljava/util/TimeZone;

    .line 183
    .line 184
    .line 185
    move-result-object v4

    .line 186
    invoke-virtual {v4, v1, v2}, Ljava/util/TimeZone;->getOffset(J)I

    .line 187
    .line 188
    .line 189
    move-result v1

    .line 190
    int-to-long v1, v1

    .line 191
    invoke-virtual {v3, v1, v2}, Ljava/util/concurrent/TimeUnit;->toSeconds(J)J

    .line 192
    .line 193
    .line 194
    move-result-wide v1

    .line 195
    iget-object v3, v0, Lfhr;->b:Lfhw;

    .line 196
    .line 197
    invoke-virtual {v3}, Lfhw;->z()Z

    .line 198
    .line 199
    .line 200
    move-result v3

    .line 201
    if-nez v3, :cond_7

    .line 202
    .line 203
    invoke-virtual {v0}, Lfhr;->l()V

    .line 204
    .line 205
    .line 206
    :cond_7
    iget-object v3, v0, Lfht;->b:Lfhw;

    .line 207
    .line 208
    check-cast v3, Lflg;

    .line 209
    .line 210
    iget v4, v3, Lflg;->b:I

    .line 211
    .line 212
    const/high16 v6, 0x20000

    .line 213
    .line 214
    or-int/2addr v4, v6

    .line 215
    iput v4, v3, Lflg;->b:I

    .line 216
    .line 217
    iput-wide v1, v3, Lflg;->h:J

    .line 218
    .line 219
    iget-object p1, p1, Lcpr;->f:Landroid/content/Context;

    .line 220
    .line 221
    invoke-static {p1}, Ldaq;->e(Landroid/content/Context;)Z

    .line 222
    .line 223
    .line 224
    move-result p1

    .line 225
    if-eqz p1, :cond_9

    .line 226
    .line 227
    iget-object p1, v0, Lfhr;->b:Lfhw;

    .line 228
    .line 229
    invoke-virtual {p1}, Lfhw;->z()Z

    .line 230
    .line 231
    .line 232
    move-result p1

    .line 233
    if-nez p1, :cond_8

    .line 234
    .line 235
    invoke-virtual {v0}, Lfhr;->l()V

    .line 236
    .line 237
    .line 238
    :cond_8
    iget-object p1, v0, Lfht;->b:Lfhw;

    .line 239
    .line 240
    check-cast p1, Lflg;

    .line 241
    .line 242
    iget v1, p1, Lflg;->b:I

    .line 243
    .line 244
    const/high16 v2, 0x800000

    .line 245
    .line 246
    or-int/2addr v1, v2

    .line 247
    iput v1, p1, Lflg;->b:I

    .line 248
    .line 249
    iput-boolean v5, p1, Lflg;->i:Z

    .line 250
    .line 251
    :cond_9
    invoke-static {}, Landroid/os/SystemClock;->elapsedRealtime()J

    .line 252
    .line 253
    .line 254
    move-result-wide v1

    .line 255
    const-wide/16 v3, 0x0

    .line 256
    .line 257
    cmp-long p1, v1, v3

    .line 258
    .line 259
    if-eqz p1, :cond_b

    .line 260
    .line 261
    iget-object p1, v0, Lfhr;->b:Lfhw;

    .line 262
    .line 263
    invoke-virtual {p1}, Lfhw;->z()Z

    .line 264
    .line 265
    .line 266
    move-result p1

    .line 267
    if-nez p1, :cond_a

    .line 268
    .line 269
    invoke-virtual {v0}, Lfhr;->l()V

    .line 270
    .line 271
    .line 272
    :cond_a
    iget-object p1, v0, Lfht;->b:Lfhw;

    .line 273
    .line 274
    check-cast p1, Lflg;

    .line 275
    .line 276
    iget v0, p1, Lflg;->b:I

    .line 277
    .line 278
    or-int/lit8 v0, v0, 0x2

    .line 279
    .line 280
    iput v0, p1, Lflg;->b:I

    .line 281
    .line 282
    iput-wide v1, p1, Lflg;->d:J

    .line 283
    .line 284
    :cond_b
    iput-object p2, p0, Lcpt;->l:Lfiz;

    .line 285
    .line 286
    return-void
    .line 287
    .line 288
    .line 289
    .line 290
    .line 291
    .line 292
    .line 293
    .line 294
    .line 295
    .line 296
    .line 297
    .line 298
    .line 299
    .line 300
    .line 301
    .line 302
    .line 303
    .line 304
    .line 305
    .line 306
    .line 307
    .line 308
    .line 309
    .line 310
    .line 311
    .line 312
    .line 313
    .line 314
    .line 315
.end method


# virtual methods
.method public final a(Lcpz;)V
    .locals 5

    .line 1
    iget-object p0, p0, Lcpt;->n:Lfht;

    .line 2
    .line 3
    iget-object v0, p0, Lfht;->b:Lfhw;

    .line 4
    .line 5
    check-cast v0, Lflg;

    .line 6
    .line 7
    iget-object v0, v0, Lflg;->l:Lfli;

    .line 8
    .line 9
    if-nez v0, :cond_0

    .line 10
    .line 11
    sget-object v0, Lfli;->a:Lfli;

    .line 12
    .line 13
    :cond_0
    const/4 v1, 0x5

    .line 14
    const/4 v2, 0x0

    .line 15
    invoke-virtual {v0, v1, v2}, Lfhw;->a(ILjava/lang/Object;)Ljava/lang/Object;

    .line 16
    .line 17
    .line 18
    move-result-object v3

    .line 19
    check-cast v3, Lfhr;

    .line 20
    .line 21
    invoke-virtual {v3, v0}, Lfhr;->n(Lfhw;)V

    .line 22
    .line 23
    .line 24
    iget-object v0, p1, Lcpz;->b:Lflh;

    .line 25
    .line 26
    check-cast v3, Lfht;

    .line 27
    .line 28
    iget-object v4, v3, Lfhr;->b:Lfhw;

    .line 29
    .line 30
    invoke-virtual {v4}, Lfhw;->z()Z

    .line 31
    .line 32
    .line 33
    move-result v4

    .line 34
    if-nez v4, :cond_1

    .line 35
    .line 36
    invoke-virtual {v3}, Lfhr;->l()V

    .line 37
    .line 38
    .line 39
    :cond_1
    iget-object v4, v3, Lfht;->b:Lfhw;

    .line 40
    .line 41
    check-cast v4, Lfli;

    .line 42
    .line 43
    iget v0, v0, Lflh;->l:I

    .line 44
    .line 45
    iput v0, v4, Lfli;->d:I

    .line 46
    .line 47
    iget v0, v4, Lfli;->b:I

    .line 48
    .line 49
    or-int/lit8 v0, v0, 0x2

    .line 50
    .line 51
    iput v0, v4, Lfli;->b:I

    .line 52
    .line 53
    iget-object v0, v4, Lfli;->c:Lfko;

    .line 54
    .line 55
    if-nez v0, :cond_2

    .line 56
    .line 57
    sget-object v0, Lfko;->a:Lfko;

    .line 58
    .line 59
    :cond_2
    invoke-virtual {v0, v1, v2}, Lfhw;->a(ILjava/lang/Object;)Ljava/lang/Object;

    .line 60
    .line 61
    .line 62
    move-result-object v4

    .line 63
    check-cast v4, Lfhr;

    .line 64
    .line 65
    invoke-virtual {v4, v0}, Lfhr;->n(Lfhw;)V

    .line 66
    .line 67
    .line 68
    iget-object v0, v4, Lfhr;->b:Lfhw;

    .line 69
    .line 70
    check-cast v0, Lfko;

    .line 71
    .line 72
    iget-object v0, v0, Lfko;->c:Lfkn;

    .line 73
    .line 74
    if-nez v0, :cond_3

    .line 75
    .line 76
    sget-object v0, Lfkn;->a:Lfkn;

    .line 77
    .line 78
    :cond_3
    invoke-virtual {v0, v1, v2}, Lfhw;->a(ILjava/lang/Object;)Ljava/lang/Object;

    .line 79
    .line 80
    .line 81
    move-result-object v1

    .line 82
    check-cast v1, Lfhr;

    .line 83
    .line 84
    invoke-virtual {v1, v0}, Lfhr;->n(Lfhw;)V

    .line 85
    .line 86
    .line 87
    iget p1, p1, Lcpz;->a:I

    .line 88
    .line 89
    iget-object v0, v1, Lfhr;->b:Lfhw;

    .line 90
    .line 91
    invoke-virtual {v0}, Lfhw;->z()Z

    .line 92
    .line 93
    .line 94
    move-result v0

    .line 95
    if-nez v0, :cond_4

    .line 96
    .line 97
    invoke-virtual {v1}, Lfhr;->l()V

    .line 98
    .line 99
    .line 100
    :cond_4
    iget-object v0, v1, Lfhr;->b:Lfhw;

    .line 101
    .line 102
    check-cast v0, Lfkn;

    .line 103
    .line 104
    iget v2, v0, Lfkn;->b:I

    .line 105
    .line 106
    or-int/lit8 v2, v2, 0x1

    .line 107
    .line 108
    iput v2, v0, Lfkn;->b:I

    .line 109
    .line 110
    iput p1, v0, Lfkn;->c:I

    .line 111
    .line 112
    iget-object p1, v4, Lfhr;->b:Lfhw;

    .line 113
    .line 114
    invoke-virtual {p1}, Lfhw;->z()Z

    .line 115
    .line 116
    .line 117
    move-result p1

    .line 118
    if-nez p1, :cond_5

    .line 119
    .line 120
    invoke-virtual {v4}, Lfhr;->l()V

    .line 121
    .line 122
    .line 123
    :cond_5
    iget-object p1, v4, Lfhr;->b:Lfhw;

    .line 124
    .line 125
    check-cast p1, Lfko;

    .line 126
    .line 127
    invoke-virtual {v1}, Lfhr;->g()Lfhw;

    .line 128
    .line 129
    .line 130
    move-result-object v0

    .line 131
    check-cast v0, Lfkn;

    .line 132
    .line 133
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 134
    .line 135
    .line 136
    iput-object v0, p1, Lfko;->c:Lfkn;

    .line 137
    .line 138
    iget v0, p1, Lfko;->b:I

    .line 139
    .line 140
    or-int/lit8 v0, v0, 0x1

    .line 141
    .line 142
    iput v0, p1, Lfko;->b:I

    .line 143
    .line 144
    iget-object p1, v3, Lfhr;->b:Lfhw;

    .line 145
    .line 146
    invoke-virtual {p1}, Lfhw;->z()Z

    .line 147
    .line 148
    .line 149
    move-result p1

    .line 150
    if-nez p1, :cond_6

    .line 151
    .line 152
    invoke-virtual {v3}, Lfhr;->l()V

    .line 153
    .line 154
    .line 155
    :cond_6
    iget-object p1, v3, Lfht;->b:Lfhw;

    .line 156
    .line 157
    check-cast p1, Lfli;

    .line 158
    .line 159
    invoke-virtual {v4}, Lfhr;->g()Lfhw;

    .line 160
    .line 161
    .line 162
    move-result-object v0

    .line 163
    check-cast v0, Lfko;

    .line 164
    .line 165
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 166
    .line 167
    .line 168
    iput-object v0, p1, Lfli;->c:Lfko;

    .line 169
    .line 170
    iget v0, p1, Lfli;->b:I

    .line 171
    .line 172
    or-int/lit8 v0, v0, 0x1

    .line 173
    .line 174
    iput v0, p1, Lfli;->b:I

    .line 175
    .line 176
    invoke-virtual {v3}, Lfhr;->g()Lfhw;

    .line 177
    .line 178
    .line 179
    move-result-object p1

    .line 180
    check-cast p1, Lfli;

    .line 181
    .line 182
    iget-object v0, p0, Lfhr;->b:Lfhw;

    .line 183
    .line 184
    invoke-virtual {v0}, Lfhw;->z()Z

    .line 185
    .line 186
    .line 187
    move-result v0

    .line 188
    if-nez v0, :cond_7

    .line 189
    .line 190
    invoke-virtual {p0}, Lfhr;->l()V

    .line 191
    .line 192
    .line 193
    :cond_7
    iget-object p0, p0, Lfht;->b:Lfhw;

    .line 194
    .line 195
    check-cast p0, Lflg;

    .line 196
    .line 197
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 198
    .line 199
    .line 200
    iput-object p1, p0, Lflg;->l:Lfli;

    .line 201
    .line 202
    iget p1, p0, Lflg;->b:I

    .line 203
    .line 204
    const/high16 v0, 0x10000000

    .line 205
    .line 206
    or-int/2addr p1, v0

    .line 207
    iput p1, p0, Lflg;->b:I

    .line 208
    .line 209
    return-void
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
    .line 261
    .line 262
    .line 263
    .line 264
    .line 265
    .line 266
    .line 267
    .line 268
    .line 269
    .line 270
    .line 271
    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    .line 277
    .line 278
    .line 279
    .line 280
    .line 281
    .line 282
    .line 283
    .line 284
    .line 285
    .line 286
    .line 287
    .line 288
    .line 289
    .line 290
    .line 291
    .line 292
    .line 293
    .line 294
    .line 295
    .line 296
    .line 297
    .line 298
    .line 299
    .line 300
    .line 301
    .line 302
    .line 303
    .line 304
    .line 305
    .line 306
    .line 307
    .line 308
    .line 309
    .line 310
    .line 311
    .line 312
    .line 313
    .line 314
    .line 315
    .line 316
    .line 317
    .line 318
    .line 319
    .line 320
    .line 321
    .line 322
    .line 323
    .line 324
    .line 325
    .line 326
    .line 327
    .line 328
    .line 329
    .line 330
    .line 331
    .line 332
    .line 333
    .line 334
    .line 335
    .line 336
    .line 337
    .line 338
    .line 339
    .line 340
    .line 341
    .line 342
    .line 343
    .line 344
    .line 345
    .line 346
    .line 347
    .line 348
    .line 349
    .line 350
    .line 351
    .line 352
    .line 353
    .line 354
    .line 355
    .line 356
    .line 357
    .line 358
    .line 359
    .line 360
    .line 361
    .line 362
    .line 363
    .line 364
    .line 365
    .line 366
    .line 367
    .line 368
    .line 369
    .line 370
    .line 371
    .line 372
    .line 373
    .line 374
    .line 375
    .line 376
    .line 377
    .line 378
    .line 379
    .line 380
    .line 381
    .line 382
    .line 383
    .line 384
    .line 385
    .line 386
    .line 387
    .line 388
    .line 389
    .line 390
    .line 391
    .line 392
    .line 393
    .line 394
    .line 395
    .line 396
    .line 397
    .line 398
    .line 399
    .line 400
    .line 401
    .line 402
    .line 403
    .line 404
    .line 405
    .line 406
    .line 407
    .line 408
    .line 409
    .line 410
    .line 411
    .line 412
    .line 413
    .line 414
    .line 415
    .line 416
    .line 417
    .line 418
    .line 419
    .line 420
    .line 421
    .line 422
    .line 423
    .line 424
    .line 425
    .line 426
    .line 427
    .line 428
    .line 429
    .line 430
    .line 431
    .line 432
    .line 433
    .line 434
    .line 435
    .line 436
    .line 437
    .line 438
    .line 439
    .line 440
    .line 441
    .line 442
    .line 443
    .line 444
    .line 445
    .line 446
    .line 447
    .line 448
    .line 449
    .line 450
    .line 451
    .line 452
    .line 453
    .line 454
    .line 455
    .line 456
    .line 457
    .line 458
    .line 459
    .line 460
    .line 461
    .line 462
    .line 463
    .line 464
    .line 465
    .line 466
    .line 467
    .line 468
    .line 469
    .line 470
    .line 471
    .line 472
    .line 473
    .line 474
    .line 475
    .line 476
    .line 477
    .line 478
    .line 479
    .line 480
    .line 481
    .line 482
    .line 483
    .line 484
    .line 485
    .line 486
    .line 487
    .line 488
    .line 489
    .line 490
    .line 491
    .line 492
    .line 493
    .line 494
    .line 495
    .line 496
    .line 497
    .line 498
    .line 499
    .line 500
    .line 501
    .line 502
    .line 503
    .line 504
    .line 505
    .line 506
    .line 507
    .line 508
    .line 509
    .line 510
    .line 511
    .line 512
    .line 513
    .line 514
    .line 515
    .line 516
    .line 517
    .line 518
    .line 519
    .line 520
    .line 521
    .line 522
    .line 523
    .line 524
    .line 525
    .line 526
    .line 527
    .line 528
    .line 529
    .line 530
    .line 531
    .line 532
    .line 533
    .line 534
    .line 535
    .line 536
    .line 537
    .line 538
    .line 539
    .line 540
    .line 541
    .line 542
    .line 543
    .line 544
    .line 545
    .line 546
    .line 547
    .line 548
    .line 549
.end method

.method public final b()Lcxu;
    .locals 10

    .line 1
    iget-boolean v0, p0, Lcpt;->b:Z

    .line 2
    .line 3
    if-nez v0, :cond_9

    .line 4
    .line 5
    const/4 v0, 0x1

    .line 6
    iput-boolean v0, p0, Lcpt;->b:Z

    .line 7
    .line 8
    iget-object v1, p0, Lcpt;->a:Lcpr;

    .line 9
    .line 10
    new-instance v2, Lcps;

    .line 11
    .line 12
    move-object v3, v1

    .line 13
    check-cast v3, Lcpv;

    .line 14
    .line 15
    iget-object v3, v3, Lcpv;->g:Lcpw;

    .line 16
    .line 17
    const/4 v4, 0x2

    .line 18
    invoke-direct {v2, v3, v4}, Lcps;-><init>(Ljava/lang/Object;I)V

    .line 19
    .line 20
    .line 21
    iget-boolean v3, p0, Lcpt;->k:Z

    .line 22
    .line 23
    const-string v4, "AbstractLogEventBuilder"

    .line 24
    .line 25
    const/4 v5, 0x0

    .line 26
    if-eqz v3, :cond_0

    .line 27
    .line 28
    const-string v1, "resolveComplianceData should not be invoked more than once per log."

    .line 29
    .line 30
    invoke-static {v4, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 31
    .line 32
    .line 33
    sget-object v1, Lfcu;->a:Lfcy;

    .line 34
    .line 35
    goto/16 :goto_2

    .line 36
    .line 37
    :cond_0
    iput-boolean v0, p0, Lcpt;->k:Z

    .line 38
    .line 39
    iget-object v3, v1, Lcpr;->k:Ldqy;

    .line 40
    .line 41
    if-eqz v3, :cond_1

    .line 42
    .line 43
    iget-object v3, v3, Ldqy;->a:Lcpz;

    .line 44
    .line 45
    goto :goto_0

    .line 46
    :cond_1
    move-object v3, v5

    .line 47
    :goto_0
    if-eqz v3, :cond_2

    .line 48
    .line 49
    iget-object v6, v3, Lcpz;->b:Lflh;

    .line 50
    .line 51
    sget-object v7, Lflh;->d:Lflh;

    .line 52
    .line 53
    if-eq v6, v7, :cond_2

    .line 54
    .line 55
    sget-object v8, Lflh;->e:Lflh;

    .line 56
    .line 57
    if-eq v6, v8, :cond_2

    .line 58
    .line 59
    invoke-virtual {v6}, Ljava/lang/Object;->toString()Ljava/lang/String;

    .line 60
    .line 61
    .line 62
    move-result-object v3

    .line 63
    invoke-static {v7}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    .line 64
    .line 65
    .line 66
    move-result-object v6

    .line 67
    invoke-static {v8}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    .line 68
    .line 69
    .line 70
    move-result-object v7

    .line 71
    new-instance v8, Ljava/lang/StringBuilder;

    .line 72
    .line 73
    const-string v9, "The provided logger-level ProductIdOrigin value "

    .line 74
    .line 75
    invoke-direct {v8, v9}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 76
    .line 77
    .line 78
    invoke-virtual {v8, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 79
    .line 80
    .line 81
    const-string v3, " is not one of the values expected for a logger-level provider: "

    .line 82
    .line 83
    invoke-virtual {v8, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 84
    .line 85
    .line 86
    invoke-virtual {v8, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 87
    .line 88
    .line 89
    const-string v3, " or "

    .line 90
    .line 91
    invoke-virtual {v8, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 92
    .line 93
    .line 94
    invoke-virtual {v8, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 95
    .line 96
    .line 97
    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 98
    .line 99
    .line 100
    move-result-object v3

    .line 101
    invoke-static {v4, v3}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 102
    .line 103
    .line 104
    move-object v3, v5

    .line 105
    :cond_2
    if-eqz v3, :cond_3

    .line 106
    .line 107
    iget-object v4, v3, Lcpz;->b:Lflh;

    .line 108
    .line 109
    sget-object v6, Lflh;->d:Lflh;

    .line 110
    .line 111
    if-ne v4, v6, :cond_3

    .line 112
    .line 113
    invoke-virtual {p0, v3}, Lcpt;->a(Lcpz;)V

    .line 114
    .line 115
    .line 116
    goto :goto_1

    .line 117
    :cond_3
    iget-object v4, p0, Lcpt;->i:Lcpz;

    .line 118
    .line 119
    if-eqz v4, :cond_4

    .line 120
    .line 121
    iget-object v6, v4, Lcpz;->b:Lflh;

    .line 122
    .line 123
    sget-object v7, Lflh;->b:Lflh;

    .line 124
    .line 125
    if-ne v6, v7, :cond_4

    .line 126
    .line 127
    invoke-virtual {p0, v4}, Lcpt;->a(Lcpz;)V

    .line 128
    .line 129
    .line 130
    goto :goto_1

    .line 131
    :cond_4
    if-eqz v3, :cond_5

    .line 132
    .line 133
    invoke-virtual {p0, v3}, Lcpt;->a(Lcpz;)V

    .line 134
    .line 135
    .line 136
    goto :goto_1

    .line 137
    :cond_5
    if-eqz v4, :cond_6

    .line 138
    .line 139
    invoke-virtual {p0, v4}, Lcpt;->a(Lcpz;)V

    .line 140
    .line 141
    .line 142
    :cond_6
    :goto_1
    invoke-virtual {v1}, Lcpr;->c()Z

    .line 143
    .line 144
    .line 145
    move-result v1

    .line 146
    if-nez v1, :cond_7

    .line 147
    .line 148
    invoke-static {v5}, Ldhf;->H(Ljava/lang/Object;)Lfcy;

    .line 149
    .line 150
    .line 151
    move-result-object v1

    .line 152
    new-instance v3, Ldlb;

    .line 153
    .line 154
    invoke-direct {v3, p0, v1, v0}, Ldlb;-><init>(Ljava/lang/Object;Ljava/lang/Object;I)V

    .line 155
    .line 156
    .line 157
    sget-object v4, Lfbz;->a:Lfbz;

    .line 158
    .line 159
    invoke-static {v1, v3, v4}, Lfbk;->j(Lfcy;Lfbt;Ljava/util/concurrent/Executor;)Lfcy;

    .line 160
    .line 161
    .line 162
    move-result-object v1

    .line 163
    new-instance v3, Lcps;

    .line 164
    .line 165
    const/4 v6, 0x0

    .line 166
    invoke-direct {v3, p0, v6}, Lcps;-><init>(Ljava/lang/Object;I)V

    .line 167
    .line 168
    .line 169
    invoke-static {v1, v3, v4}, Lfbk;->i(Lfcy;Leql;Ljava/util/concurrent/Executor;)Lfcy;

    .line 170
    .line 171
    .line 172
    move-result-object v1

    .line 173
    goto :goto_2

    .line 174
    :cond_7
    sget-object v1, Lfcu;->a:Lfcy;

    .line 175
    .line 176
    :goto_2
    invoke-interface {v1}, Lfcy;->isDone()Z

    .line 177
    .line 178
    .line 179
    move-result v3

    .line 180
    if-eqz v3, :cond_8

    .line 181
    .line 182
    invoke-interface {v1}, Lfcy;->isCancelled()Z

    .line 183
    .line 184
    .line 185
    move-result v3

    .line 186
    if-nez v3, :cond_8

    .line 187
    .line 188
    :try_start_0
    invoke-static {v1}, La;->f(Ljava/util/concurrent/Future;)Ljava/lang/Object;
    :try_end_0
    .catch Ljava/util/concurrent/ExecutionException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_0} :catch_0

    .line 189
    .line 190
    .line 191
    invoke-interface {v2, p0}, Leql;->a(Ljava/lang/Object;)Ljava/lang/Object;

    .line 192
    .line 193
    .line 194
    move-result-object p0

    .line 195
    goto :goto_3

    .line 196
    :catch_0
    :cond_8
    new-instance v3, Lddh;

    .line 197
    .line 198
    invoke-direct {v3, v5, v5}, Lddh;-><init>([B[C)V

    .line 199
    .line 200
    .line 201
    iget-object v4, v3, Lddh;->a:Ljava/lang/Object;

    .line 202
    .line 203
    new-instance v5, Lddh;

    .line 204
    .line 205
    check-cast v4, Lddh;

    .line 206
    .line 207
    invoke-direct {v5, v4}, Lddh;-><init>(Lddh;)V

    .line 208
    .line 209
    .line 210
    new-instance v4, Ldar;

    .line 211
    .line 212
    invoke-direct {v4, v5, v1, v3}, Ldar;-><init>(Lddh;Lfcy;Lddh;)V

    .line 213
    .line 214
    .line 215
    sget-object v3, Lfbz;->a:Lfbz;

    .line 216
    .line 217
    invoke-static {v1, v4, v3}, Ldhf;->N(Lfcy;Lfcm;Ljava/util/concurrent/Executor;)V

    .line 218
    .line 219
    .line 220
    iget-object v1, v5, Lddh;->a:Ljava/lang/Object;

    .line 221
    .line 222
    new-instance v4, Lcwy;

    .line 223
    .line 224
    invoke-direct {v4, v2, p0, v0}, Lcwy;-><init>(Leql;Lcpt;I)V

    .line 225
    .line 226
    .line 227
    check-cast v1, Lcxu;

    .line 228
    .line 229
    invoke-virtual {v1, v3, v4}, Lcxu;->a(Ljava/util/concurrent/Executor;Lcxl;)Lcxu;

    .line 230
    .line 231
    .line 232
    move-result-object p0

    .line 233
    :goto_3
    check-cast p0, Lcxu;

    .line 234
    .line 235
    return-object p0

    .line 236
    :cond_9
    new-instance p0, Ljava/lang/IllegalStateException;

    .line 237
    .line 238
    const-string v0, "do not reuse LogEventBuilder"

    .line 239
    .line 240
    invoke-direct {p0, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 241
    .line 242
    .line 243
    throw p0
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
    .line 261
    .line 262
    .line 263
    .line 264
    .line 265
    .line 266
    .line 267
    .line 268
    .line 269
    .line 270
    .line 271
    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    .line 277
    .line 278
    .line 279
    .line 280
    .line 281
    .line 282
    .line 283
    .line 284
    .line 285
    .line 286
    .line 287
    .line 288
    .line 289
    .line 290
    .line 291
    .line 292
    .line 293
    .line 294
    .line 295
    .line 296
    .line 297
    .line 298
    .line 299
    .line 300
    .line 301
    .line 302
    .line 303
    .line 304
    .line 305
    .line 306
    .line 307
    .line 308
    .line 309
    .line 310
    .line 311
    .line 312
    .line 313
    .line 314
    .line 315
    .line 316
    .line 317
    .line 318
    .line 319
    .line 320
    .line 321
    .line 322
    .line 323
    .line 324
    .line 325
    .line 326
    .line 327
    .line 328
    .line 329
    .line 330
    .line 331
    .line 332
    .line 333
    .line 334
    .line 335
    .line 336
    .line 337
    .line 338
    .line 339
    .line 340
    .line 341
    .line 342
    .line 343
    .line 344
    .line 345
    .line 346
    .line 347
    .line 348
    .line 349
    .line 350
    .line 351
    .line 352
    .line 353
    .line 354
    .line 355
    .line 356
    .line 357
    .line 358
    .line 359
    .line 360
    .line 361
    .line 362
    .line 363
    .line 364
    .line 365
    .line 366
    .line 367
    .line 368
    .line 369
    .line 370
    .line 371
    .line 372
    .line 373
    .line 374
    .line 375
    .line 376
    .line 377
    .line 378
    .line 379
    .line 380
    .line 381
    .line 382
    .line 383
    .line 384
    .line 385
    .line 386
    .line 387
    .line 388
    .line 389
    .line 390
    .line 391
    .line 392
    .line 393
    .line 394
    .line 395
    .line 396
    .line 397
    .line 398
    .line 399
    .line 400
    .line 401
    .line 402
    .line 403
    .line 404
    .line 405
    .line 406
    .line 407
    .line 408
    .line 409
    .line 410
    .line 411
    .line 412
    .line 413
    .line 414
    .line 415
    .line 416
    .line 417
    .line 418
    .line 419
    .line 420
    .line 421
    .line 422
    .line 423
    .line 424
    .line 425
    .line 426
    .line 427
    .line 428
    .line 429
    .line 430
    .line 431
    .line 432
    .line 433
    .line 434
    .line 435
    .line 436
    .line 437
    .line 438
    .line 439
    .line 440
    .line 441
    .line 442
    .line 443
    .line 444
    .line 445
    .line 446
    .line 447
    .line 448
    .line 449
    .line 450
    .line 451
    .line 452
    .line 453
    .line 454
    .line 455
    .line 456
    .line 457
    .line 458
    .line 459
    .line 460
    .line 461
    .line 462
    .line 463
    .line 464
    .line 465
    .line 466
    .line 467
    .line 468
    .line 469
    .line 470
    .line 471
    .line 472
    .line 473
    .line 474
    .line 475
    .line 476
    .line 477
    .line 478
    .line 479
    .line 480
    .line 481
    .line 482
    .line 483
    .line 484
    .line 485
    .line 486
    .line 487
    .line 488
    .line 489
    .line 490
    .line 491
    .line 492
    .line 493
    .line 494
    .line 495
    .line 496
    .line 497
    .line 498
    .line 499
    .line 500
    .line 501
    .line 502
    .line 503
    .line 504
    .line 505
    .line 506
    .line 507
    .line 508
    .line 509
    .line 510
    .line 511
    .line 512
    .line 513
    .line 514
    .line 515
    .line 516
    .line 517
    .line 518
    .line 519
    .line 520
    .line 521
    .line 522
    .line 523
    .line 524
    .line 525
    .line 526
    .line 527
    .line 528
    .line 529
    .line 530
    .line 531
    .line 532
    .line 533
    .line 534
    .line 535
    .line 536
    .line 537
    .line 538
    .line 539
    .line 540
    .line 541
    .line 542
    .line 543
    .line 544
    .line 545
    .line 546
    .line 547
    .line 548
    .line 549
    .line 550
    .line 551
    .line 552
    .line 553
    .line 554
    .line 555
    .line 556
    .line 557
    .line 558
    .line 559
    .line 560
    .line 561
    .line 562
    .line 563
    .line 564
    .line 565
    .line 566
    .line 567
    .line 568
    .line 569
    .line 570
    .line 571
    .line 572
    .line 573
    .line 574
    .line 575
    .line 576
    .line 577
    .line 578
    .line 579
    .line 580
    .line 581
    .line 582
    .line 583
    .line 584
    .line 585
    .line 586
    .line 587
    .line 588
    .line 589
    .line 590
    .line 591
    .line 592
    .line 593
    .line 594
    .line 595
    .line 596
    .line 597
    .line 598
    .line 599
    .line 600
    .line 601
    .line 602
    .line 603
    .line 604
    .line 605
    .line 606
    .line 607
    .line 608
    .line 609
    .line 610
    .line 611
    .line 612
    .line 613
    .line 614
    .line 615
    .line 616
    .line 617
    .line 618
    .line 619
    .line 620
    .line 621
    .line 622
    .line 623
    .line 624
    .line 625
    .line 626
    .line 627
    .line 628
    .line 629
    .line 630
    .line 631
    .line 632
    .line 633
    .line 634
    .line 635
    .line 636
    .line 637
    .line 638
    .line 639
    .line 640
    .line 641
    .line 642
    .line 643
    .line 644
    .line 645
    .line 646
    .line 647
    .line 648
    .line 649
    .line 650
    .line 651
    .line 652
    .line 653
    .line 654
    .line 655
    .line 656
.end method

.method public final c([I)V
    .locals 4

    .line 1
    iget-object v0, p0, Lcpt;->a:Lcpr;

    .line 2
    .line 3
    invoke-virtual {v0}, Lcpr;->c()Z

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    if-nez v0, :cond_3

    .line 8
    .line 9
    array-length v0, p1

    .line 10
    if-nez v0, :cond_0

    .line 11
    .line 12
    goto :goto_1

    .line 13
    :cond_0
    iget-object v1, p0, Lcpt;->d:Ljava/util/ArrayList;

    .line 14
    .line 15
    const/4 v2, 0x0

    .line 16
    if-nez v1, :cond_1

    .line 17
    .line 18
    new-instance v1, Ljava/util/ArrayList;

    .line 19
    .line 20
    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 21
    .line 22
    .line 23
    iput-object v1, p0, Lcpt;->d:Ljava/util/ArrayList;

    .line 24
    .line 25
    :cond_1
    :goto_0
    if-ge v2, v0, :cond_2

    .line 26
    .line 27
    aget v1, p1, v2

    .line 28
    .line 29
    iget-object v3, p0, Lcpt;->d:Ljava/util/ArrayList;

    .line 30
    .line 31
    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 32
    .line 33
    .line 34
    move-result-object v1

    .line 35
    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 36
    .line 37
    .line 38
    add-int/lit8 v2, v2, 0x1

    .line 39
    .line 40
    goto :goto_0

    .line 41
    :cond_2
    :goto_1
    return-void

    .line 42
    :cond_3
    new-instance p0, Ljava/lang/IllegalArgumentException;

    .line 43
    .line 44
    const-string p1, "addExperimentIds forbidden on deidentified logger"

    .line 45
    .line 46
    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 47
    .line 48
    .line 49
    throw p0
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
.end method

.method public final toString()Ljava/lang/String;
    .locals 3

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    .line 2
    .line 3
    const-string v1, "AbstractLogEventBuilderuploadAccount: "

    .line 4
    .line 5
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    iget-object v1, p0, Lcpt;->g:Ljava/lang/String;

    .line 9
    .line 10
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 11
    .line 12
    .line 13
    const-string v1, ", logSourceName: "

    .line 14
    .line 15
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 16
    .line 17
    .line 18
    iget-object v1, p0, Lcpt;->h:Ljava/lang/String;

    .line 19
    .line 20
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 21
    .line 22
    .line 23
    const-string v1, ", qosTier: 0, veMessage: null, testCodes: null, mendelPackages: "

    .line 24
    .line 25
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 26
    .line 27
    .line 28
    iget-object v1, p0, Lcpt;->c:Ljava/util/ArrayList;

    .line 29
    .line 30
    const/4 v2, 0x0

    .line 31
    if-eqz v1, :cond_0

    .line 32
    .line 33
    invoke-static {v1}, Lcpr;->a(Ljava/lang/Iterable;)Ljava/lang/String;

    .line 34
    .line 35
    .line 36
    move-result-object v1

    .line 37
    goto :goto_0

    .line 38
    :cond_0
    move-object v1, v2

    .line 39
    :goto_0
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 40
    .line 41
    .line 42
    const-string v1, ", experimentIds: "

    .line 43
    .line 44
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 45
    .line 46
    .line 47
    iget-object v1, p0, Lcpt;->d:Ljava/util/ArrayList;

    .line 48
    .line 49
    if-eqz v1, :cond_1

    .line 50
    .line 51
    invoke-static {v1}, Lcpr;->a(Ljava/lang/Iterable;)Ljava/lang/String;

    .line 52
    .line 53
    .line 54
    move-result-object v1

    .line 55
    goto :goto_1

    .line 56
    :cond_1
    move-object v1, v2

    .line 57
    :goto_1
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 58
    .line 59
    .line 60
    const-string v1, ", experimentTokens: "

    .line 61
    .line 62
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 63
    .line 64
    .line 65
    iget-object p0, p0, Lcpt;->e:Ljava/util/ArrayList;

    .line 66
    .line 67
    if-eqz p0, :cond_2

    .line 68
    .line 69
    invoke-static {p0}, Lcpr;->a(Ljava/lang/Iterable;)Ljava/lang/String;

    .line 70
    .line 71
    .line 72
    move-result-object v2

    .line 73
    :cond_2
    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 74
    .line 75
    .line 76
    const-string p0, ", addPhenotype: true]"

    .line 77
    .line 78
    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 79
    .line 80
    .line 81
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 82
    .line 83
    .line 84
    move-result-object p0

    .line 85
    return-object p0
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
.end method
