.class public final Lbps;
.super Lfsr;
.source "PG"

# interfaces
.implements Lftr;


# instance fields
.field a:I

.field final synthetic b:Ljava/lang/Object;

.field private final synthetic c:I


# direct methods
.method public constructor <init>(Landroidx/work/impl/workers/ConstraintTrackingWorker;Lfrz;I)V
    .locals 0

    .line 1
    iput p3, p0, Lbps;->c:I

    iput-object p1, p0, Lbps;->b:Ljava/lang/Object;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p2}, Lfsr;-><init>(ILfrz;)V

    return-void
.end method

.method public constructor <init>(Lblb;Lfrz;I)V
    .locals 0

    .line 2
    iput p3, p0, Lbps;->c:I

    iput-object p1, p0, Lbps;->b:Ljava/lang/Object;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p2}, Lfsr;-><init>(ILfrz;)V

    return-void
.end method

.method public constructor <init>(Lcom/google/android/wearable/watchface/koru/artsandculture/ArtsAndCultureWatchFaceService;Lfrz;I)V
    .locals 0

    .line 3
    iput p3, p0, Lbps;->c:I

    iput-object p1, p0, Lbps;->b:Ljava/lang/Object;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p2}, Lfsr;-><init>(ILfrz;)V

    return-void
.end method

.method public constructor <init>(Lcom/google/android/wearable/watchface/koru/artsandculture/ArtsAndCultureWatchFaceService;Lfrz;I[B)V
    .locals 0

    .line 4
    iput p3, p0, Lbps;->c:I

    iput-object p1, p0, Lbps;->b:Ljava/lang/Object;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p2}, Lfsr;-><init>(ILfrz;)V

    return-void
.end method

.method public constructor <init>(Lcom/google/android/wearable/watchface/koru/artsandculture/datastore/scheduler/FetchFutureArtworkSchedulerService;Lfrz;I)V
    .locals 0

    .line 5
    iput p3, p0, Lbps;->c:I

    iput-object p1, p0, Lbps;->b:Ljava/lang/Object;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p2}, Lfsr;-><init>(ILfrz;)V

    return-void
.end method

.method public constructor <init>(Ldrv;Lfrz;I)V
    .locals 0

    .line 6
    iput p3, p0, Lbps;->c:I

    iput-object p1, p0, Lbps;->b:Ljava/lang/Object;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p2}, Lfsr;-><init>(ILfrz;)V

    return-void
.end method

.method public constructor <init>(Ldrv;Lfrz;I[B)V
    .locals 0

    .line 7
    iput p3, p0, Lbps;->c:I

    iput-object p1, p0, Lbps;->b:Ljava/lang/Object;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p2}, Lfsr;-><init>(ILfrz;)V

    return-void
.end method

.method public constructor <init>(Leif;Lfrz;I)V
    .locals 0

    .line 8
    iput p3, p0, Lbps;->c:I

    iput-object p1, p0, Lbps;->b:Ljava/lang/Object;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p2}, Lfsr;-><init>(ILfrz;)V

    return-void
.end method

.method public constructor <init>(Leif;Lfrz;I[B)V
    .locals 0

    .line 9
    iput p3, p0, Lbps;->c:I

    iput-object p1, p0, Lbps;->b:Ljava/lang/Object;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p2}, Lfsr;-><init>(ILfrz;)V

    return-void
.end method

.method public constructor <init>(Leif;Lfrz;I[C)V
    .locals 0

    .line 10
    iput p3, p0, Lbps;->c:I

    iput-object p1, p0, Lbps;->b:Ljava/lang/Object;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p2}, Lfsr;-><init>(ILfrz;)V

    return-void
.end method

.method public constructor <init>(Lejd;Lfrz;I)V
    .locals 0

    .line 11
    iput p3, p0, Lbps;->c:I

    iput-object p1, p0, Lbps;->b:Ljava/lang/Object;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p2}, Lfsr;-><init>(ILfrz;)V

    return-void
.end method

.method public constructor <init>(Lejm;Lfrz;I)V
    .locals 0

    .line 12
    iput p3, p0, Lbps;->c:I

    iput-object p1, p0, Lbps;->b:Ljava/lang/Object;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p2}, Lfsr;-><init>(ILfrz;)V

    return-void
.end method

.method public constructor <init>(Lejm;Lfrz;I[B)V
    .locals 0

    .line 13
    iput p3, p0, Lbps;->c:I

    iput-object p1, p0, Lbps;->b:Ljava/lang/Object;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p2}, Lfsr;-><init>(ILfrz;)V

    return-void
.end method

.method public constructor <init>(Lejm;Lfrz;I[C)V
    .locals 0

    .line 14
    iput p3, p0, Lbps;->c:I

    iput-object p1, p0, Lbps;->b:Ljava/lang/Object;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p2}, Lfsr;-><init>(ILfrz;)V

    return-void
.end method

.method public constructor <init>(Lekq;Lfrz;I)V
    .locals 0

    .line 15
    iput p3, p0, Lbps;->c:I

    iput-object p1, p0, Lbps;->b:Ljava/lang/Object;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p2}, Lfsr;-><init>(ILfrz;)V

    return-void
.end method

.method public constructor <init>(Lfcy;Lfrz;I)V
    .locals 0

    .line 16
    iput p3, p0, Lbps;->c:I

    iput-object p1, p0, Lbps;->b:Ljava/lang/Object;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p2}, Lfsr;-><init>(ILfrz;)V

    return-void
.end method

.method public constructor <init>(Lgbj;Lfrz;I)V
    .locals 0

    .line 17
    iput p3, p0, Lbps;->c:I

    iput-object p1, p0, Lbps;->b:Ljava/lang/Object;

    const/4 p1, 0x2

    invoke-direct {p0, p1, p2}, Lfsr;-><init>(ILfrz;)V

    return-void
.end method


# virtual methods
.method public final synthetic a(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 1

    .line 1
    iget v0, p0, Lbps;->c:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    check-cast p1, Lfxq;

    .line 7
    .line 8
    check-cast p2, Lfrz;

    .line 9
    .line 10
    invoke-virtual {p0, p1, p2}, Lfsl;->b(Ljava/lang/Object;Lfrz;)Lfrz;

    .line 11
    .line 12
    .line 13
    move-result-object p0

    .line 14
    sget-object p1, Lfqj;->a:Lfqj;

    .line 15
    .line 16
    check-cast p0, Lbps;

    .line 17
    .line 18
    invoke-virtual {p0, p1}, Lbps;->aY(Ljava/lang/Object;)Ljava/lang/Object;

    .line 19
    .line 20
    .line 21
    move-result-object p0

    .line 22
    return-object p0

    .line 23
    :pswitch_0
    check-cast p1, Lfxq;

    .line 24
    .line 25
    check-cast p2, Lfrz;

    .line 26
    .line 27
    invoke-virtual {p0, p1, p2}, Lfsl;->b(Ljava/lang/Object;Lfrz;)Lfrz;

    .line 28
    .line 29
    .line 30
    move-result-object p0

    .line 31
    sget-object p1, Lfqj;->a:Lfqj;

    .line 32
    .line 33
    check-cast p0, Lbps;

    .line 34
    .line 35
    invoke-virtual {p0, p1}, Lbps;->aY(Ljava/lang/Object;)Ljava/lang/Object;

    .line 36
    .line 37
    .line 38
    move-result-object p0

    .line 39
    return-object p0

    .line 40
    :pswitch_1
    check-cast p1, Lfxq;

    .line 41
    .line 42
    check-cast p2, Lfrz;

    .line 43
    .line 44
    invoke-virtual {p0, p1, p2}, Lfsl;->b(Ljava/lang/Object;Lfrz;)Lfrz;

    .line 45
    .line 46
    .line 47
    move-result-object p0

    .line 48
    sget-object p1, Lfqj;->a:Lfqj;

    .line 49
    .line 50
    check-cast p0, Lbps;

    .line 51
    .line 52
    invoke-virtual {p0, p1}, Lbps;->aY(Ljava/lang/Object;)Ljava/lang/Object;

    .line 53
    .line 54
    .line 55
    move-result-object p0

    .line 56
    return-object p0

    .line 57
    :pswitch_2
    check-cast p1, Lfxq;

    .line 58
    .line 59
    check-cast p2, Lfrz;

    .line 60
    .line 61
    invoke-virtual {p0, p1, p2}, Lfsl;->b(Ljava/lang/Object;Lfrz;)Lfrz;

    .line 62
    .line 63
    .line 64
    move-result-object p0

    .line 65
    sget-object p1, Lfqj;->a:Lfqj;

    .line 66
    .line 67
    check-cast p0, Lbps;

    .line 68
    .line 69
    invoke-virtual {p0, p1}, Lbps;->aY(Ljava/lang/Object;)Ljava/lang/Object;

    .line 70
    .line 71
    .line 72
    move-result-object p0

    .line 73
    return-object p0

    .line 74
    :pswitch_3
    check-cast p1, Lfxq;

    .line 75
    .line 76
    check-cast p2, Lfrz;

    .line 77
    .line 78
    invoke-virtual {p0, p1, p2}, Lfsl;->b(Ljava/lang/Object;Lfrz;)Lfrz;

    .line 79
    .line 80
    .line 81
    move-result-object p0

    .line 82
    sget-object p1, Lfqj;->a:Lfqj;

    .line 83
    .line 84
    check-cast p0, Lbps;

    .line 85
    .line 86
    invoke-virtual {p0, p1}, Lbps;->aY(Ljava/lang/Object;)Ljava/lang/Object;

    .line 87
    .line 88
    .line 89
    move-result-object p0

    .line 90
    return-object p0

    .line 91
    :pswitch_4
    check-cast p1, Lfxq;

    .line 92
    .line 93
    check-cast p2, Lfrz;

    .line 94
    .line 95
    invoke-virtual {p0, p1, p2}, Lfsl;->b(Ljava/lang/Object;Lfrz;)Lfrz;

    .line 96
    .line 97
    .line 98
    move-result-object p0

    .line 99
    sget-object p1, Lfqj;->a:Lfqj;

    .line 100
    .line 101
    check-cast p0, Lbps;

    .line 102
    .line 103
    invoke-virtual {p0, p1}, Lbps;->aY(Ljava/lang/Object;)Ljava/lang/Object;

    .line 104
    .line 105
    .line 106
    move-result-object p0

    .line 107
    return-object p0

    .line 108
    :pswitch_5
    check-cast p1, Lfxq;

    .line 109
    .line 110
    check-cast p2, Lfrz;

    .line 111
    .line 112
    invoke-virtual {p0, p1, p2}, Lfsl;->b(Ljava/lang/Object;Lfrz;)Lfrz;

    .line 113
    .line 114
    .line 115
    move-result-object p0

    .line 116
    sget-object p1, Lfqj;->a:Lfqj;

    .line 117
    .line 118
    check-cast p0, Lbps;

    .line 119
    .line 120
    invoke-virtual {p0, p1}, Lbps;->aY(Ljava/lang/Object;)Ljava/lang/Object;

    .line 121
    .line 122
    .line 123
    move-result-object p0

    .line 124
    return-object p0

    .line 125
    :pswitch_6
    check-cast p1, Lfxq;

    .line 126
    .line 127
    check-cast p2, Lfrz;

    .line 128
    .line 129
    invoke-virtual {p0, p1, p2}, Lfsl;->b(Ljava/lang/Object;Lfrz;)Lfrz;

    .line 130
    .line 131
    .line 132
    move-result-object p0

    .line 133
    sget-object p1, Lfqj;->a:Lfqj;

    .line 134
    .line 135
    check-cast p0, Lbps;

    .line 136
    .line 137
    invoke-virtual {p0, p1}, Lbps;->aY(Ljava/lang/Object;)Ljava/lang/Object;

    .line 138
    .line 139
    .line 140
    move-result-object p0

    .line 141
    return-object p0

    .line 142
    :pswitch_7
    check-cast p1, Lfxq;

    .line 143
    .line 144
    check-cast p2, Lfrz;

    .line 145
    .line 146
    invoke-virtual {p0, p1, p2}, Lfsl;->b(Ljava/lang/Object;Lfrz;)Lfrz;

    .line 147
    .line 148
    .line 149
    move-result-object p0

    .line 150
    sget-object p1, Lfqj;->a:Lfqj;

    .line 151
    .line 152
    check-cast p0, Lbps;

    .line 153
    .line 154
    invoke-virtual {p0, p1}, Lbps;->aY(Ljava/lang/Object;)Ljava/lang/Object;

    .line 155
    .line 156
    .line 157
    move-result-object p0

    .line 158
    return-object p0

    .line 159
    :pswitch_8
    check-cast p1, Lfxq;

    .line 160
    .line 161
    check-cast p2, Lfrz;

    .line 162
    .line 163
    invoke-virtual {p0, p1, p2}, Lfsl;->b(Ljava/lang/Object;Lfrz;)Lfrz;

    .line 164
    .line 165
    .line 166
    move-result-object p0

    .line 167
    sget-object p1, Lfqj;->a:Lfqj;

    .line 168
    .line 169
    check-cast p0, Lbps;

    .line 170
    .line 171
    invoke-virtual {p0, p1}, Lbps;->aY(Ljava/lang/Object;)Ljava/lang/Object;

    .line 172
    .line 173
    .line 174
    move-result-object p0

    .line 175
    return-object p0

    .line 176
    :pswitch_9
    check-cast p1, Lfxq;

    .line 177
    .line 178
    check-cast p2, Lfrz;

    .line 179
    .line 180
    invoke-virtual {p0, p1, p2}, Lfsl;->b(Ljava/lang/Object;Lfrz;)Lfrz;

    .line 181
    .line 182
    .line 183
    move-result-object p0

    .line 184
    sget-object p1, Lfqj;->a:Lfqj;

    .line 185
    .line 186
    check-cast p0, Lbps;

    .line 187
    .line 188
    invoke-virtual {p0, p1}, Lbps;->aY(Ljava/lang/Object;)Ljava/lang/Object;

    .line 189
    .line 190
    .line 191
    move-result-object p0

    .line 192
    return-object p0

    .line 193
    :pswitch_a
    check-cast p1, Lfxq;

    .line 194
    .line 195
    check-cast p2, Lfrz;

    .line 196
    .line 197
    invoke-virtual {p0, p1, p2}, Lfsl;->b(Ljava/lang/Object;Lfrz;)Lfrz;

    .line 198
    .line 199
    .line 200
    move-result-object p0

    .line 201
    sget-object p1, Lfqj;->a:Lfqj;

    .line 202
    .line 203
    check-cast p0, Lbps;

    .line 204
    .line 205
    invoke-virtual {p0, p1}, Lbps;->aY(Ljava/lang/Object;)Ljava/lang/Object;

    .line 206
    .line 207
    .line 208
    move-result-object p0

    .line 209
    return-object p0

    .line 210
    :pswitch_b
    check-cast p1, Lfxq;

    .line 211
    .line 212
    check-cast p2, Lfrz;

    .line 213
    .line 214
    invoke-virtual {p0, p1, p2}, Lfsl;->b(Ljava/lang/Object;Lfrz;)Lfrz;

    .line 215
    .line 216
    .line 217
    move-result-object p0

    .line 218
    sget-object p1, Lfqj;->a:Lfqj;

    .line 219
    .line 220
    check-cast p0, Lbps;

    .line 221
    .line 222
    invoke-virtual {p0, p1}, Lbps;->aY(Ljava/lang/Object;)Ljava/lang/Object;

    .line 223
    .line 224
    .line 225
    move-result-object p0

    .line 226
    return-object p0

    .line 227
    :pswitch_c
    check-cast p1, Lfxq;

    .line 228
    .line 229
    check-cast p2, Lfrz;

    .line 230
    .line 231
    invoke-virtual {p0, p1, p2}, Lfsl;->b(Ljava/lang/Object;Lfrz;)Lfrz;

    .line 232
    .line 233
    .line 234
    move-result-object p0

    .line 235
    sget-object p1, Lfqj;->a:Lfqj;

    .line 236
    .line 237
    check-cast p0, Lbps;

    .line 238
    .line 239
    invoke-virtual {p0, p1}, Lbps;->aY(Ljava/lang/Object;)Ljava/lang/Object;

    .line 240
    .line 241
    .line 242
    move-result-object p0

    .line 243
    return-object p0

    .line 244
    :pswitch_d
    check-cast p1, Lfxq;

    .line 245
    .line 246
    check-cast p2, Lfrz;

    .line 247
    .line 248
    invoke-virtual {p0, p1, p2}, Lfsl;->b(Ljava/lang/Object;Lfrz;)Lfrz;

    .line 249
    .line 250
    .line 251
    move-result-object p0

    .line 252
    sget-object p1, Lfqj;->a:Lfqj;

    .line 253
    .line 254
    check-cast p0, Lbps;

    .line 255
    .line 256
    invoke-virtual {p0, p1}, Lbps;->aY(Ljava/lang/Object;)Ljava/lang/Object;

    .line 257
    .line 258
    .line 259
    move-result-object p0

    .line 260
    return-object p0

    .line 261
    :pswitch_e
    check-cast p1, Lfxq;

    .line 262
    .line 263
    check-cast p2, Lfrz;

    .line 264
    .line 265
    invoke-virtual {p0, p1, p2}, Lfsl;->b(Ljava/lang/Object;Lfrz;)Lfrz;

    .line 266
    .line 267
    .line 268
    move-result-object p0

    .line 269
    sget-object p1, Lfqj;->a:Lfqj;

    .line 270
    .line 271
    check-cast p0, Lbps;

    .line 272
    .line 273
    invoke-virtual {p0, p1}, Lbps;->aY(Ljava/lang/Object;)Ljava/lang/Object;

    .line 274
    .line 275
    .line 276
    move-result-object p0

    .line 277
    return-object p0

    .line 278
    :pswitch_f
    check-cast p1, Lfxq;

    .line 279
    .line 280
    check-cast p2, Lfrz;

    .line 281
    .line 282
    invoke-virtual {p0, p1, p2}, Lfsl;->b(Ljava/lang/Object;Lfrz;)Lfrz;

    .line 283
    .line 284
    .line 285
    move-result-object p0

    .line 286
    sget-object p1, Lfqj;->a:Lfqj;

    .line 287
    .line 288
    check-cast p0, Lbps;

    .line 289
    .line 290
    invoke-virtual {p0, p1}, Lbps;->aY(Ljava/lang/Object;)Ljava/lang/Object;

    .line 291
    .line 292
    .line 293
    move-result-object p0

    .line 294
    return-object p0

    .line 295
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
    .line 296
    .line 297
    .line 298
    .line 299
    .line 300
    .line 301
    .line 302
    .line 303
    .line 304
    .line 305
    .line 306
    .line 307
    .line 308
    .line 309
    .line 310
    .line 311
    .line 312
    .line 313
    .line 314
    .line 315
.end method

.method public final aY(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 7

    .line 1
    iget v0, p0, Lbps;->c:I

    .line 2
    .line 3
    const/4 v1, 0x5

    .line 4
    const/4 v2, 0x0

    .line 5
    const/4 v3, 0x0

    .line 6
    const/4 v4, 0x1

    .line 7
    packed-switch v0, :pswitch_data_0

    .line 8
    .line 9
    .line 10
    sget-object v0, Lfsg;->a:Lfsg;

    .line 11
    .line 12
    iget v1, p0, Lbps;->a:I

    .line 13
    .line 14
    invoke-static {p1}, Lcma;->bD(Ljava/lang/Object;)V

    .line 15
    .line 16
    .line 17
    if-eqz v1, :cond_32

    .line 18
    .line 19
    goto/16 :goto_15

    .line 20
    .line 21
    :pswitch_0
    sget-object v0, Lfsg;->a:Lfsg;

    .line 22
    .line 23
    iget v1, p0, Lbps;->a:I

    .line 24
    .line 25
    if-nez v1, :cond_1

    .line 26
    .line 27
    invoke-static {p1}, Lcma;->bD(Ljava/lang/Object;)V

    .line 28
    .line 29
    .line 30
    iget-object p1, p0, Lbps;->b:Ljava/lang/Object;

    .line 31
    .line 32
    move-object v1, p1

    .line 33
    check-cast v1, Lekq;

    .line 34
    .line 35
    iget-object v1, v1, Lekq;->a:Lejd;

    .line 36
    .line 37
    iget-object v1, v1, Lejd;->E:Lkotlinx/coroutines/flow/MutableStateFlow;

    .line 38
    .line 39
    if-eqz v1, :cond_0

    .line 40
    .line 41
    new-instance v2, Lazf;

    .line 42
    .line 43
    const/4 v3, 0x6

    .line 44
    invoke-direct {v2, p1, v3}, Lazf;-><init>(Ljava/lang/Object;I)V

    .line 45
    .line 46
    .line 47
    iput v4, p0, Lbps;->a:I

    .line 48
    .line 49
    invoke-interface {v1, v2, p0}, Lkotlinx/coroutines/flow/MutableStateFlow;->a(Lgbk;Lfrz;)Ljava/lang/Object;

    .line 50
    .line 51
    .line 52
    move-result-object p0

    .line 53
    if-ne p0, v0, :cond_2

    .line 54
    .line 55
    return-object v0

    .line 56
    :cond_0
    sget-object p0, Lfqj;->a:Lfqj;

    .line 57
    .line 58
    return-object p0

    .line 59
    :cond_1
    invoke-static {p1}, Lcma;->bD(Ljava/lang/Object;)V

    .line 60
    .line 61
    .line 62
    :cond_2
    new-instance p0, Lfpu;

    .line 63
    .line 64
    invoke-direct {p0}, Lfpu;-><init>()V

    .line 65
    .line 66
    .line 67
    throw p0

    .line 68
    :pswitch_1
    sget-object v0, Lfsg;->a:Lfsg;

    .line 69
    .line 70
    iget v1, p0, Lbps;->a:I

    .line 71
    .line 72
    if-eqz v1, :cond_4

    .line 73
    .line 74
    if-eq v1, v4, :cond_3

    .line 75
    .line 76
    invoke-static {p1}, Lcma;->bD(Ljava/lang/Object;)V

    .line 77
    .line 78
    .line 79
    goto :goto_2

    .line 80
    :cond_3
    invoke-static {p1}, Lcma;->bD(Ljava/lang/Object;)V

    .line 81
    .line 82
    .line 83
    goto :goto_0

    .line 84
    :cond_4
    invoke-static {p1}, Lcma;->bD(Ljava/lang/Object;)V

    .line 85
    .line 86
    .line 87
    iget-object p1, p0, Lbps;->b:Ljava/lang/Object;

    .line 88
    .line 89
    new-instance v1, Ljava/lang/StringBuilder;

    .line 90
    .line 91
    const-string v3, "running whsWatchDog timer: "

    .line 92
    .line 93
    invoke-direct {v1, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 94
    .line 95
    .line 96
    move-object v3, p1

    .line 97
    check-cast v3, Lejm;

    .line 98
    .line 99
    iget-wide v5, v3, Lejm;->n:J

    .line 100
    .line 101
    invoke-virtual {v1, v5, v6}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 102
    .line 103
    .line 104
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 105
    .line 106
    .line 107
    move-result-object v1

    .line 108
    invoke-static {p1, v1}, Ldds;->U(Leku;Ljava/lang/String;)V

    .line 109
    .line 110
    .line 111
    iput v4, p0, Lbps;->a:I

    .line 112
    .line 113
    invoke-static {v5, v6, p0}, Lfxt;->g(JLfrz;)Ljava/lang/Object;

    .line 114
    .line 115
    .line 116
    move-result-object p1

    .line 117
    if-ne p1, v0, :cond_5

    .line 118
    .line 119
    goto :goto_1

    .line 120
    :cond_5
    :goto_0
    iget-object p1, p0, Lbps;->b:Ljava/lang/Object;

    .line 121
    .line 122
    move-object v1, p1

    .line 123
    check-cast v1, Lejm;

    .line 124
    .line 125
    iget-boolean v3, v1, Lejm;->o:Z

    .line 126
    .line 127
    if-nez v3, :cond_7

    .line 128
    .line 129
    iget-wide v2, v1, Lejm;->n:J

    .line 130
    .line 131
    new-instance v4, Ljava/lang/StringBuilder;

    .line 132
    .line 133
    const-string v5, "No WHS update received in last: "

    .line 134
    .line 135
    invoke-direct {v4, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 136
    .line 137
    .line 138
    invoke-virtual {v4, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 139
    .line 140
    .line 141
    const-string v2, " ms, did it crash? Attempting to deregister and re-register."

    .line 142
    .line 143
    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 144
    .line 145
    .line 146
    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 147
    .line 148
    .line 149
    move-result-object v2

    .line 150
    invoke-static {p1, v2}, Ldds;->ab(Leku;Ljava/lang/String;)V

    .line 151
    .line 152
    .line 153
    iget-object p1, v1, Lejm;->q:Lyo;

    .line 154
    .line 155
    const/4 v1, 0x2

    .line 156
    iput v1, p0, Lbps;->a:I

    .line 157
    .line 158
    invoke-static {p1, p0}, Lua;->k(Lyo;Lfrz;)Ljava/lang/Object;

    .line 159
    .line 160
    .line 161
    move-result-object p1

    .line 162
    if-ne p1, v0, :cond_6

    .line 163
    .line 164
    :goto_1
    return-object v0

    .line 165
    :cond_6
    :goto_2
    iget-object p0, p0, Lbps;->b:Ljava/lang/Object;

    .line 166
    .line 167
    check-cast p0, Lejm;

    .line 168
    .line 169
    invoke-virtual {p0}, Lejm;->b()V

    .line 170
    .line 171
    .line 172
    goto :goto_3

    .line 173
    :cond_7
    iget-wide v3, v1, Lejm;->n:J

    .line 174
    .line 175
    new-instance p0, Ljava/lang/StringBuilder;

    .line 176
    .line 177
    const-string v0, "WHS update received in last: "

    .line 178
    .line 179
    invoke-direct {p0, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 180
    .line 181
    .line 182
    invoke-virtual {p0, v3, v4}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    .line 183
    .line 184
    .line 185
    const-string v0, " ms.  Restarting WatchDog..."

    .line 186
    .line 187
    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 188
    .line 189
    .line 190
    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 191
    .line 192
    .line 193
    move-result-object p0

    .line 194
    invoke-static {p1, p0}, Ldds;->U(Leku;Ljava/lang/String;)V

    .line 195
    .line 196
    .line 197
    iput-boolean v2, v1, Lejm;->o:Z

    .line 198
    .line 199
    invoke-virtual {v1}, Lejm;->c()V

    .line 200
    .line 201
    .line 202
    :goto_3
    sget-object p0, Lfqj;->a:Lfqj;

    .line 203
    .line 204
    return-object p0

    .line 205
    :pswitch_2
    sget-object v0, Lfsg;->a:Lfsg;

    .line 206
    .line 207
    iget v3, p0, Lbps;->a:I

    .line 208
    .line 209
    if-eqz v3, :cond_8

    .line 210
    .line 211
    invoke-static {p1}, Lcma;->bD(Ljava/lang/Object;)V

    .line 212
    .line 213
    .line 214
    goto :goto_5

    .line 215
    :cond_8
    invoke-static {p1}, Lcma;->bD(Ljava/lang/Object;)V

    .line 216
    .line 217
    .line 218
    iget-object p1, p0, Lbps;->b:Ljava/lang/Object;

    .line 219
    .line 220
    sget-object v3, Lejm;->e:Ljava/util/Set;

    .line 221
    .line 222
    filled-new-array {v3}, [Ljava/lang/Object;

    .line 223
    .line 224
    .line 225
    move-result-object v3

    .line 226
    const-string v5, "Desired WHS Passive Metrics: %s"

    .line 227
    .line 228
    invoke-static {p1, v5, v3}, Ldds;->V(Leku;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 229
    .line 230
    .line 231
    check-cast p1, Lejm;

    .line 232
    .line 233
    iget-object p1, p1, Lejm;->q:Lyo;

    .line 234
    .line 235
    invoke-virtual {p1}, Lyo;->b()Lfcy;

    .line 236
    .line 237
    .line 238
    move-result-object p1

    .line 239
    iput v4, p0, Lbps;->a:I

    .line 240
    .line 241
    :try_start_0
    invoke-interface {p1}, Lfcy;->isDone()Z

    .line 242
    .line 243
    .line 244
    move-result v3

    .line 245
    if-eqz v3, :cond_9

    .line 246
    .line 247
    invoke-static {p1}, La;->f(Ljava/util/concurrent/Future;)Ljava/lang/Object;

    .line 248
    .line 249
    .line 250
    move-result-object p1
    :try_end_0
    .catch Ljava/util/concurrent/ExecutionException; {:try_start_0 .. :try_end_0} :catch_0

    .line 251
    goto :goto_4

    .line 252
    :cond_9
    new-instance v3, Lfwz;

    .line 253
    .line 254
    invoke-static {p0}, Lfug;->k(Lfrz;)Lfrz;

    .line 255
    .line 256
    .line 257
    move-result-object v5

    .line 258
    invoke-direct {v3, v5, v4}, Lfwz;-><init>(Lfrz;I)V

    .line 259
    .line 260
    .line 261
    invoke-virtual {v3}, Lfwz;->x()V

    .line 262
    .line 263
    .line 264
    new-instance v5, Lbjy;

    .line 265
    .line 266
    invoke-direct {v5, p1, v3, v1}, Lbjy;-><init>(Lfcy;Lfwy;I)V

    .line 267
    .line 268
    .line 269
    sget-object v1, Lfbz;->a:Lfbz;

    .line 270
    .line 271
    invoke-interface {p1, v5, v1}, Lfcy;->c(Ljava/lang/Runnable;Ljava/util/concurrent/Executor;)V

    .line 272
    .line 273
    .line 274
    new-instance v1, Lgdc;

    .line 275
    .line 276
    invoke-direct {v1, p1, v2}, Lgdc;-><init>(Ljava/lang/Object;I)V

    .line 277
    .line 278
    .line 279
    invoke-interface {v3, v1}, Lfwy;->b(Lftn;)V

    .line 280
    .line 281
    .line 282
    invoke-virtual {v3}, Lfwz;->k()Ljava/lang/Object;

    .line 283
    .line 284
    .line 285
    move-result-object p1

    .line 286
    sget-object v1, Lfsg;->a:Lfsg;

    .line 287
    .line 288
    :goto_4
    if-ne p1, v0, :cond_a

    .line 289
    .line 290
    return-object v0

    .line 291
    :cond_a
    :goto_5
    check-cast p1, Lxy;

    .line 292
    .line 293
    iget-object p1, p1, Lxy;->a:Ljava/util/Set;

    .line 294
    .line 295
    iget-object p0, p0, Lbps;->b:Ljava/lang/Object;

    .line 296
    .line 297
    filled-new-array {p1}, [Ljava/lang/Object;

    .line 298
    .line 299
    .line 300
    move-result-object v0

    .line 301
    const-string v1, "Supported WHS Passive Metrics: %s"

    .line 302
    .line 303
    invoke-static {p0, v1, v0}, Ldds;->V(Leku;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 304
    .line 305
    .line 306
    sget-boolean v0, Lejm;->a:Z

    .line 307
    .line 308
    if-eqz v0, :cond_d

    .line 309
    .line 310
    sget-object v0, Lejm;->d:Ljava/util/Set;

    .line 311
    .line 312
    new-instance v1, Ljava/util/ArrayList;

    .line 313
    .line 314
    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 315
    .line 316
    .line 317
    new-instance v2, Ljava/util/ArrayList;

    .line 318
    .line 319
    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    .line 320
    .line 321
    .line 322
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 323
    .line 324
    .line 325
    move-result-object v0

    .line 326
    :goto_6
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 327
    .line 328
    .line 329
    move-result v3

    .line 330
    if-eqz v3, :cond_c

    .line 331
    .line 332
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 333
    .line 334
    .line 335
    move-result-object v3

    .line 336
    move-object v5, v3

    .line 337
    check-cast v5, Lxm;

    .line 338
    .line 339
    invoke-interface {p1, v5}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 340
    .line 341
    .line 342
    move-result v5

    .line 343
    if-eqz v5, :cond_b

    .line 344
    .line 345
    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 346
    .line 347
    .line 348
    goto :goto_6

    .line 349
    :cond_b
    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 350
    .line 351
    .line 352
    goto :goto_6

    .line 353
    :cond_c
    new-instance p1, Lfpy;

    .line 354
    .line 355
    invoke-direct {p1, v1, v2}, Lfpy;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 356
    .line 357
    .line 358
    goto :goto_8

    .line 359
    :cond_d
    sget-object v0, Lejm;->e:Ljava/util/Set;

    .line 360
    .line 361
    new-instance v1, Ljava/util/ArrayList;

    .line 362
    .line 363
    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 364
    .line 365
    .line 366
    new-instance v2, Ljava/util/ArrayList;

    .line 367
    .line 368
    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    .line 369
    .line 370
    .line 371
    invoke-interface {v0}, Ljava/lang/Iterable;->iterator()Ljava/util/Iterator;

    .line 372
    .line 373
    .line 374
    move-result-object v0

    .line 375
    :goto_7
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    .line 376
    .line 377
    .line 378
    move-result v3

    .line 379
    if-eqz v3, :cond_f

    .line 380
    .line 381
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 382
    .line 383
    .line 384
    move-result-object v3

    .line 385
    move-object v5, v3

    .line 386
    check-cast v5, Lxm;

    .line 387
    .line 388
    invoke-interface {p1, v5}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    .line 389
    .line 390
    .line 391
    move-result v5

    .line 392
    if-eqz v5, :cond_e

    .line 393
    .line 394
    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 395
    .line 396
    .line 397
    goto :goto_7

    .line 398
    :cond_e
    invoke-virtual {v2, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 399
    .line 400
    .line 401
    goto :goto_7

    .line 402
    :cond_f
    new-instance p1, Lfpy;

    .line 403
    .line 404
    invoke-direct {p1, v1, v2}, Lfpy;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 405
    .line 406
    .line 407
    :goto_8
    iget-object v0, p1, Lfpy;->b:Ljava/lang/Object;

    .line 408
    .line 409
    iget-object p1, p1, Lfpy;->a:Ljava/lang/Object;

    .line 410
    .line 411
    check-cast p1, Ljava/util/List;

    .line 412
    .line 413
    check-cast v0, Ljava/util/List;

    .line 414
    .line 415
    invoke-interface {v0}, Ljava/util/Collection;->isEmpty()Z

    .line 416
    .line 417
    .line 418
    move-result v1

    .line 419
    if-nez v1, :cond_10

    .line 420
    .line 421
    invoke-static {v0}, Ljava/util/Objects;->toString(Ljava/lang/Object;)Ljava/lang/String;

    .line 422
    .line 423
    .line 424
    invoke-static {v0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    .line 425
    .line 426
    .line 427
    move-result-object v0

    .line 428
    const-string v1, "These desired WHS metrics are NOT SUPPORTED!: "

    .line 429
    .line 430
    invoke-virtual {v1, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    .line 431
    .line 432
    .line 433
    move-result-object v0

    .line 434
    invoke-static {p0, v0}, Ldds;->X(Leku;Ljava/lang/String;)V

    .line 435
    .line 436
    .line 437
    :cond_10
    filled-new-array {p1}, [Ljava/lang/Object;

    .line 438
    .line 439
    .line 440
    move-result-object v0

    .line 441
    const-string v1, "Requested WHS metrics: %s"

    .line 442
    .line 443
    invoke-static {p0, v1, v0}, Ldds;->V(Leku;Ljava/lang/String;[Ljava/lang/Object;)V

    .line 444
    .line 445
    .line 446
    invoke-static {p1}, Lcma;->aI(Ljava/lang/Iterable;)Ljava/util/Set;

    .line 447
    .line 448
    .line 449
    move-result-object p1

    .line 450
    move-object v0, p0

    .line 451
    check-cast v0, Lejm;

    .line 452
    .line 453
    iput-object p1, v0, Lejm;->i:Ljava/util/Set;

    .line 454
    .line 455
    new-instance p1, Ldye;

    .line 456
    .line 457
    iget-object v1, v0, Lejm;->i:Ljava/util/Set;

    .line 458
    .line 459
    sget-object v2, Lfqz;->a:Lfqz;

    .line 460
    .line 461
    invoke-direct {p1, v1, v4, v2, v2}, Ldye;-><init>(Ljava/util/Set;ZLjava/util/Set;Ljava/util/Set;)V

    .line 462
    .line 463
    .line 464
    iget-object v0, v0, Lejm;->q:Lyo;

    .line 465
    .line 466
    new-instance v1, Landroidx/wear/ambient/AmbientMode$AmbientController;

    .line 467
    .line 468
    invoke-direct {v1, p0}, Landroidx/wear/ambient/AmbientMode$AmbientController;-><init>(Ljava/lang/Object;)V

    .line 469
    .line 470
    .line 471
    invoke-virtual {v0, p1, v1}, Lyo;->c(Ldye;Landroidx/wear/ambient/AmbientMode$AmbientController;)V

    .line 472
    .line 473
    .line 474
    sget-object p0, Lfqj;->a:Lfqj;

    .line 475
    .line 476
    return-object p0

    .line 477
    :catch_0
    move-exception p0

    .line 478
    invoke-static {p0}, Lfuu;->v(Ljava/util/concurrent/ExecutionException;)Ljava/lang/Throwable;

    .line 479
    .line 480
    .line 481
    move-result-object p0

    .line 482
    throw p0

    .line 483
    :pswitch_3
    sget-object v0, Lfsg;->a:Lfsg;

    .line 484
    .line 485
    iget v1, p0, Lbps;->a:I

    .line 486
    .line 487
    if-eqz v1, :cond_11

    .line 488
    .line 489
    invoke-static {p1}, Lcma;->bD(Ljava/lang/Object;)V

    .line 490
    .line 491
    .line 492
    goto :goto_9

    .line 493
    :cond_11
    invoke-static {p1}, Lcma;->bD(Ljava/lang/Object;)V

    .line 494
    .line 495
    .line 496
    iget-object p1, p0, Lbps;->b:Ljava/lang/Object;

    .line 497
    .line 498
    const-string v1, "onDestroy() called"

    .line 499
    .line 500
    invoke-static {p1, v1}, Ldds;->U(Leku;Ljava/lang/String;)V

    .line 501
    .line 502
    .line 503
    iput v4, p0, Lbps;->a:I

    .line 504
    .line 505
    check-cast p1, Lejm;

    .line 506
    .line 507
    iget-object p1, p1, Lejm;->q:Lyo;

    .line 508
    .line 509
    invoke-static {p1, p0}, Lua;->k(Lyo;Lfrz;)Ljava/lang/Object;

    .line 510
    .line 511
    .line 512
    move-result-object p1

    .line 513
    if-ne p1, v0, :cond_12

    .line 514
    .line 515
    return-object v0

    .line 516
    :cond_12
    :goto_9
    iget-object p0, p0, Lbps;->b:Ljava/lang/Object;

    .line 517
    .line 518
    check-cast p0, Lejm;

    .line 519
    .line 520
    iget-object p1, p0, Lejm;->m:Lfyx;

    .line 521
    .line 522
    if-eqz p1, :cond_13

    .line 523
    .line 524
    invoke-static {p1}, Lfug;->w(Lfyx;)V

    .line 525
    .line 526
    .line 527
    :cond_13
    iget-object p0, p0, Lejm;->p:Lfyx;

    .line 528
    .line 529
    if-nez p0, :cond_14

    .line 530
    .line 531
    return-object v3

    .line 532
    :cond_14
    invoke-static {p0}, Lfug;->w(Lfyx;)V

    .line 533
    .line 534
    .line 535
    sget-object p0, Lfqj;->a:Lfqj;

    .line 536
    .line 537
    return-object p0

    .line 538
    :pswitch_4
    sget-object v0, Lfsg;->a:Lfsg;

    .line 539
    .line 540
    iget v1, p0, Lbps;->a:I

    .line 541
    .line 542
    if-eqz v1, :cond_15

    .line 543
    .line 544
    invoke-static {p1}, Lcma;->bD(Ljava/lang/Object;)V

    .line 545
    .line 546
    .line 547
    return-object p1

    .line 548
    :cond_15
    invoke-static {p1}, Lcma;->bD(Ljava/lang/Object;)V

    .line 549
    .line 550
    .line 551
    iget-object p1, p0, Lbps;->b:Ljava/lang/Object;

    .line 552
    .line 553
    new-instance v1, Lejc;

    .line 554
    .line 555
    invoke-direct {v1, v3}, Lejc;-><init>(Lfrz;)V

    .line 556
    .line 557
    .line 558
    iput v4, p0, Lbps;->a:I

    .line 559
    .line 560
    check-cast p1, Lejd;

    .line 561
    .line 562
    iget-object p1, p1, Lejd;->E:Lkotlinx/coroutines/flow/MutableStateFlow;

    .line 563
    .line 564
    invoke-static {p1, v1, p0}, Lfuj;->U(Lgbj;Lftr;Lfrz;)Ljava/lang/Object;

    .line 565
    .line 566
    .line 567
    move-result-object p0

    .line 568
    if-ne p0, v0, :cond_16

    .line 569
    .line 570
    return-object v0

    .line 571
    :cond_16
    return-object p0

    .line 572
    :pswitch_5
    sget-object v0, Lfsg;->a:Lfsg;

    .line 573
    .line 574
    iget v2, p0, Lbps;->a:I

    .line 575
    .line 576
    if-nez v2, :cond_17

    .line 577
    .line 578
    invoke-static {p1}, Lcma;->bD(Ljava/lang/Object;)V

    .line 579
    .line 580
    .line 581
    iget-object p1, p0, Lbps;->b:Ljava/lang/Object;

    .line 582
    .line 583
    new-instance v2, Lazf;

    .line 584
    .line 585
    invoke-direct {v2, p1, v1}, Lazf;-><init>(Ljava/lang/Object;I)V

    .line 586
    .line 587
    .line 588
    iput v4, p0, Lbps;->a:I

    .line 589
    .line 590
    check-cast p1, Leif;

    .line 591
    .line 592
    iget-object p1, p1, Leif;->c:Lbag;

    .line 593
    .line 594
    iget-object p1, p1, Lbag;->d:Lgca;

    .line 595
    .line 596
    invoke-interface {p1, v2, p0}, Lgca;->a(Lgbk;Lfrz;)Ljava/lang/Object;

    .line 597
    .line 598
    .line 599
    move-result-object p0

    .line 600
    if-ne p0, v0, :cond_18

    .line 601
    .line 602
    return-object v0

    .line 603
    :cond_17
    invoke-static {p1}, Lcma;->bD(Ljava/lang/Object;)V

    .line 604
    .line 605
    .line 606
    :cond_18
    new-instance p0, Lfpu;

    .line 607
    .line 608
    invoke-direct {p0}, Lfpu;-><init>()V

    .line 609
    .line 610
    .line 611
    throw p0

    .line 612
    :pswitch_6
    sget-object v0, Lfsg;->a:Lfsg;

    .line 613
    .line 614
    iget v1, p0, Lbps;->a:I

    .line 615
    .line 616
    if-eqz v1, :cond_19

    .line 617
    .line 618
    invoke-static {p1}, Lcma;->bD(Ljava/lang/Object;)V

    .line 619
    .line 620
    .line 621
    goto :goto_a

    .line 622
    :cond_19
    invoke-static {p1}, Lcma;->bD(Ljava/lang/Object;)V

    .line 623
    .line 624
    .line 625
    iget-object p1, p0, Lbps;->b:Ljava/lang/Object;

    .line 626
    .line 627
    check-cast p1, Leif;

    .line 628
    .line 629
    iget-object v1, p1, Leif;->a:Lejd;

    .line 630
    .line 631
    iput-boolean v4, v1, Lejd;->I:Z

    .line 632
    .line 633
    sget-object v2, Leic;->a:Leic;

    .line 634
    .line 635
    invoke-virtual {p1, v2}, Leif;->r(Leic;)V

    .line 636
    .line 637
    .line 638
    iput v4, p0, Lbps;->a:I

    .line 639
    .line 640
    const-wide/16 v2, 0x3e8

    .line 641
    .line 642
    invoke-static {v1, v2, v3, p0}, Lejd;->L(Lejd;JLfrz;)Ljava/lang/Object;

    .line 643
    .line 644
    .line 645
    move-result-object p1

    .line 646
    if-ne p1, v0, :cond_1a

    .line 647
    .line 648
    return-object v0

    .line 649
    :cond_1a
    :goto_a
    check-cast p1, Ljava/lang/Boolean;

    .line 650
    .line 651
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 652
    .line 653
    .line 654
    move-result p1

    .line 655
    if-nez p1, :cond_1b

    .line 656
    .line 657
    iget-object p1, p0, Lbps;->b:Ljava/lang/Object;

    .line 658
    .line 659
    const-string v0, "watchfaceView cannot be modified after 1 second of waiting"

    .line 660
    .line 661
    invoke-static {p1, v0}, Ldds;->X(Leku;Ljava/lang/String;)V

    .line 662
    .line 663
    .line 664
    :cond_1b
    iget-object p0, p0, Lbps;->b:Ljava/lang/Object;

    .line 665
    .line 666
    move-object p1, p0

    .line 667
    check-cast p1, Leif;

    .line 668
    .line 669
    iget-object p1, p1, Leif;->a:Lejd;

    .line 670
    .line 671
    iget-object p1, p1, Lejd;->K:Lcom/google/android/clockwork/pele/KoruRenderer;

    .line 672
    .line 673
    if-eqz p1, :cond_1c

    .line 674
    .line 675
    invoke-virtual {p1}, Lcom/google/android/clockwork/pele/KoruRenderer;->getKoruMainThreadHandler()Landroid/os/Handler;

    .line 676
    .line 677
    .line 678
    move-result-object p1

    .line 679
    if-eqz p1, :cond_1c

    .line 680
    .line 681
    new-instance v0, Ldnd;

    .line 682
    .line 683
    const/16 v1, 0x13

    .line 684
    .line 685
    invoke-direct {v0, p0, v1}, Ldnd;-><init>(Ljava/lang/Object;I)V

    .line 686
    .line 687
    .line 688
    invoke-virtual {p1, v0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    .line 689
    .line 690
    .line 691
    :cond_1c
    sget-object p0, Lfqj;->a:Lfqj;

    .line 692
    .line 693
    return-object p0

    .line 694
    :pswitch_7
    sget-object v0, Lfsg;->a:Lfsg;

    .line 695
    .line 696
    iget v1, p0, Lbps;->a:I

    .line 697
    .line 698
    if-eqz v1, :cond_1d

    .line 699
    .line 700
    invoke-static {p1}, Lcma;->bD(Ljava/lang/Object;)V

    .line 701
    .line 702
    .line 703
    goto :goto_b

    .line 704
    :cond_1d
    invoke-static {p1}, Lcma;->bD(Ljava/lang/Object;)V

    .line 705
    .line 706
    .line 707
    iget-object p1, p0, Lbps;->b:Ljava/lang/Object;

    .line 708
    .line 709
    iput v4, p0, Lbps;->a:I

    .line 710
    .line 711
    check-cast p1, Leif;

    .line 712
    .line 713
    iget-object p1, p1, Leif;->a:Lejd;

    .line 714
    .line 715
    const-wide/16 v1, 0x1f4

    .line 716
    .line 717
    invoke-static {p1, v1, v2, p0}, Lejd;->L(Lejd;JLfrz;)Ljava/lang/Object;

    .line 718
    .line 719
    .line 720
    move-result-object p1

    .line 721
    if-ne p1, v0, :cond_1e

    .line 722
    .line 723
    return-object v0

    .line 724
    :cond_1e
    :goto_b
    check-cast p1, Ljava/lang/Boolean;

    .line 725
    .line 726
    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    .line 727
    .line 728
    .line 729
    move-result p1

    .line 730
    if-nez p1, :cond_1f

    .line 731
    .line 732
    iget-object p0, p0, Lbps;->b:Ljava/lang/Object;

    .line 733
    .line 734
    const-string p1, "onPreOffloadEnd - view access not granted after 500 milliseconds"

    .line 735
    .line 736
    invoke-static {p0, p1}, Ldds;->X(Leku;Ljava/lang/String;)V

    .line 737
    .line 738
    .line 739
    :cond_1f
    sget-object p0, Lfqj;->a:Lfqj;

    .line 740
    .line 741
    return-object p0

    .line 742
    :pswitch_8
    sget-object v0, Lfsg;->a:Lfsg;

    .line 743
    .line 744
    iget v1, p0, Lbps;->a:I

    .line 745
    .line 746
    if-eqz v1, :cond_20

    .line 747
    .line 748
    invoke-static {p1}, Lcma;->bD(Ljava/lang/Object;)V

    .line 749
    .line 750
    .line 751
    goto :goto_d

    .line 752
    :cond_20
    invoke-static {p1}, Lcma;->bD(Ljava/lang/Object;)V

    .line 753
    .line 754
    .line 755
    iget-object p1, p0, Lbps;->b:Ljava/lang/Object;

    .line 756
    .line 757
    iput v4, p0, Lbps;->a:I

    .line 758
    .line 759
    check-cast p1, Lcom/google/android/wearable/watchface/koru/artsandculture/datastore/scheduler/FetchFutureArtworkSchedulerService;

    .line 760
    .line 761
    iget-object v1, p1, Lcom/google/android/wearable/watchface/koru/artsandculture/datastore/scheduler/FetchFutureArtworkSchedulerService;->b:Lfan;

    .line 762
    .line 763
    if-nez v1, :cond_21

    .line 764
    .line 765
    const-string v1, "timeSource"

    .line 766
    .line 767
    invoke-static {v1}, Lfuj;->b(Ljava/lang/String;)V

    .line 768
    .line 769
    .line 770
    goto :goto_c

    .line 771
    :cond_21
    move-object v3, v1

    .line 772
    :goto_c
    invoke-interface {v3}, Lfan;->a()Lj$/time/Instant;

    .line 773
    .line 774
    .line 775
    move-result-object v1

    .line 776
    invoke-static {}, Lj$/time/ZoneId;->systemDefault()Lj$/time/ZoneId;

    .line 777
    .line 778
    .line 779
    move-result-object v2

    .line 780
    invoke-virtual {v1, v2}, Lj$/time/Instant;->atZone(Lj$/time/ZoneId;)Lj$/time/ZonedDateTime;

    .line 781
    .line 782
    .line 783
    move-result-object v1

    .line 784
    invoke-virtual {v1}, Lj$/time/ZonedDateTime;->toLocalDate()Lj$/time/LocalDate;

    .line 785
    .line 786
    .line 787
    move-result-object v1

    .line 788
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 789
    .line 790
    .line 791
    invoke-virtual {p1, v1, p0}, Lcom/google/android/wearable/watchface/koru/artsandculture/datastore/scheduler/FetchFutureArtworkSchedulerService;->a(Lj$/time/LocalDate;Lfrz;)Ljava/lang/Object;

    .line 792
    .line 793
    .line 794
    move-result-object p0

    .line 795
    if-eq p0, v0, :cond_22

    .line 796
    .line 797
    sget-object p0, Lfqj;->a:Lfqj;

    .line 798
    .line 799
    :cond_22
    if-ne p0, v0, :cond_23

    .line 800
    .line 801
    return-object v0

    .line 802
    :cond_23
    :goto_d
    sget-object p0, Lfqj;->a:Lfqj;

    .line 803
    .line 804
    return-object p0

    .line 805
    :pswitch_9
    sget-object v0, Lfsg;->a:Lfsg;

    .line 806
    .line 807
    iget v1, p0, Lbps;->a:I

    .line 808
    .line 809
    if-eqz v1, :cond_24

    .line 810
    .line 811
    :try_start_1
    invoke-static {p1}, Lcma;->bD(Ljava/lang/Object;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 812
    .line 813
    .line 814
    goto :goto_e

    .line 815
    :cond_24
    invoke-static {p1}, Lcma;->bD(Ljava/lang/Object;)V

    .line 816
    .line 817
    .line 818
    :try_start_2
    iget-object p1, p0, Lbps;->b:Ljava/lang/Object;

    .line 819
    .line 820
    iput v4, p0, Lbps;->a:I

    .line 821
    .line 822
    invoke-static {p1, p0}, Llr;->i(Lfcy;Lfrz;)Ljava/lang/Object;

    .line 823
    .line 824
    .line 825
    move-result-object p0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    .line 826
    if-ne p0, v0, :cond_25

    .line 827
    .line 828
    return-object v0

    .line 829
    :catchall_0
    move-exception p0

    .line 830
    sget-object p1, Lcom/google/android/wearable/watchface/koru/artsandculture/ArtsAndCultureWatchFaceService;->c:Leul;

    .line 831
    .line 832
    invoke-virtual {p1}, Leud;->f()Leuz;

    .line 833
    .line 834
    .line 835
    move-result-object p1

    .line 836
    invoke-interface {p1, p0}, Leuk;->h(Ljava/lang/Throwable;)Leuz;

    .line 837
    .line 838
    .line 839
    move-result-object p0

    .line 840
    const-string p1, "invokeSuspend"

    .line 841
    .line 842
    const/16 v0, 0x194

    .line 843
    .line 844
    const-string v1, "com/google/android/wearable/watchface/koru/artsandculture/ArtsAndCultureWatchFaceService$openArtworkOnPhone$1"

    .line 845
    .line 846
    const-string v2, "ArtsAndCultureWatchFaceService.kt"

    .line 847
    .line 848
    invoke-interface {p0, v1, p1, v0, v2}, Leuz;->i(Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;)Leuz;

    .line 849
    .line 850
    .line 851
    move-result-object p0

    .line 852
    check-cast p0, Leuk;

    .line 853
    .line 854
    const-string p1, "Failed to open arts and culture page on phone"

    .line 855
    .line 856
    invoke-interface {p0, p1}, Leuk;->o(Ljava/lang/String;)V

    .line 857
    .line 858
    .line 859
    :cond_25
    :goto_e
    sget-object p0, Lfqj;->a:Lfqj;

    .line 860
    .line 861
    return-object p0

    .line 862
    :pswitch_a
    sget-object v0, Lfsg;->a:Lfsg;

    .line 863
    .line 864
    iget v1, p0, Lbps;->a:I

    .line 865
    .line 866
    if-eqz v1, :cond_26

    .line 867
    .line 868
    invoke-static {p1}, Lcma;->bD(Ljava/lang/Object;)V

    .line 869
    .line 870
    .line 871
    goto :goto_f

    .line 872
    :cond_26
    invoke-static {p1}, Lcma;->bD(Ljava/lang/Object;)V

    .line 873
    .line 874
    .line 875
    iget-object p1, p0, Lbps;->b:Ljava/lang/Object;

    .line 876
    .line 877
    invoke-static {}, Lj$/time/LocalDate;->now()Lj$/time/LocalDate;

    .line 878
    .line 879
    .line 880
    move-result-object v1

    .line 881
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 882
    .line 883
    .line 884
    iput v4, p0, Lbps;->a:I

    .line 885
    .line 886
    check-cast p1, Lcom/google/android/wearable/watchface/koru/artsandculture/ArtsAndCultureWatchFaceService;

    .line 887
    .line 888
    invoke-virtual {p1, v1, p0}, Lcom/google/android/wearable/watchface/koru/artsandculture/ArtsAndCultureWatchFaceService;->h(Lj$/time/LocalDate;Lfrz;)Ljava/lang/Object;

    .line 889
    .line 890
    .line 891
    move-result-object p1

    .line 892
    if-ne p1, v0, :cond_27

    .line 893
    .line 894
    return-object v0

    .line 895
    :cond_27
    :goto_f
    iget-object p0, p0, Lbps;->b:Ljava/lang/Object;

    .line 896
    .line 897
    check-cast p0, Lcom/google/android/wearable/watchface/koru/artsandculture/ArtsAndCultureWatchFaceService;

    .line 898
    .line 899
    invoke-virtual {p0, v2, v4}, Lcom/google/android/wearable/watchface/koru/artsandculture/ArtsAndCultureWatchFaceService;->E(ZZ)V

    .line 900
    .line 901
    .line 902
    sget-object p0, Lfqj;->a:Lfqj;

    .line 903
    .line 904
    return-object p0

    .line 905
    :pswitch_b
    sget-object v0, Lfsg;->a:Lfsg;

    .line 906
    .line 907
    iget v1, p0, Lbps;->a:I

    .line 908
    .line 909
    if-eqz v1, :cond_28

    .line 910
    .line 911
    invoke-static {p1}, Lcma;->bD(Ljava/lang/Object;)V

    .line 912
    .line 913
    .line 914
    goto :goto_10

    .line 915
    :cond_28
    invoke-static {p1}, Lcma;->bD(Ljava/lang/Object;)V

    .line 916
    .line 917
    .line 918
    iget-object p1, p0, Lbps;->b:Ljava/lang/Object;

    .line 919
    .line 920
    invoke-static {}, Lj$/time/LocalDate;->now()Lj$/time/LocalDate;

    .line 921
    .line 922
    .line 923
    move-result-object v1

    .line 924
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 925
    .line 926
    .line 927
    iput v4, p0, Lbps;->a:I

    .line 928
    .line 929
    check-cast p1, Lcom/google/android/wearable/watchface/koru/artsandculture/ArtsAndCultureWatchFaceService;

    .line 930
    .line 931
    invoke-virtual {p1, v1, p0}, Lcom/google/android/wearable/watchface/koru/artsandculture/ArtsAndCultureWatchFaceService;->h(Lj$/time/LocalDate;Lfrz;)Ljava/lang/Object;

    .line 932
    .line 933
    .line 934
    move-result-object p1

    .line 935
    if-ne p1, v0, :cond_29

    .line 936
    .line 937
    return-object v0

    .line 938
    :cond_29
    :goto_10
    iget-object p0, p0, Lbps;->b:Ljava/lang/Object;

    .line 939
    .line 940
    check-cast p0, Lcom/google/android/wearable/watchface/koru/artsandculture/ArtsAndCultureWatchFaceService;

    .line 941
    .line 942
    invoke-virtual {p0, v4, v4}, Lcom/google/android/wearable/watchface/koru/artsandculture/ArtsAndCultureWatchFaceService;->E(ZZ)V

    .line 943
    .line 944
    .line 945
    sget-object p0, Lfqj;->a:Lfqj;

    .line 946
    .line 947
    return-object p0

    .line 948
    :pswitch_c
    sget-object v0, Lfsg;->a:Lfsg;

    .line 949
    .line 950
    iget v1, p0, Lbps;->a:I

    .line 951
    .line 952
    if-nez v1, :cond_2a

    .line 953
    .line 954
    invoke-static {p1}, Lcma;->bD(Ljava/lang/Object;)V

    .line 955
    .line 956
    .line 957
    iget-object p1, p0, Lbps;->b:Ljava/lang/Object;

    .line 958
    .line 959
    sget v1, Ldrv;->I:I

    .line 960
    .line 961
    move-object v1, p1

    .line 962
    check-cast v1, Ldrv;

    .line 963
    .line 964
    iget-object v1, v1, Ldrv;->y:Lbag;

    .line 965
    .line 966
    iget-object v1, v1, Lbag;->d:Lgca;

    .line 967
    .line 968
    new-instance v2, Lazf;

    .line 969
    .line 970
    const/4 v3, 0x4

    .line 971
    invoke-direct {v2, p1, v3}, Lazf;-><init>(Ljava/lang/Object;I)V

    .line 972
    .line 973
    .line 974
    iput v4, p0, Lbps;->a:I

    .line 975
    .line 976
    invoke-interface {v1, v2, p0}, Lgca;->a(Lgbk;Lfrz;)Ljava/lang/Object;

    .line 977
    .line 978
    .line 979
    move-result-object p0

    .line 980
    if-ne p0, v0, :cond_2b

    .line 981
    .line 982
    return-object v0

    .line 983
    :cond_2a
    invoke-static {p1}, Lcma;->bD(Ljava/lang/Object;)V

    .line 984
    .line 985
    .line 986
    :cond_2b
    new-instance p0, Lfpu;

    .line 987
    .line 988
    invoke-direct {p0}, Lfpu;-><init>()V

    .line 989
    .line 990
    .line 991
    throw p0

    .line 992
    :pswitch_d
    sget-object v0, Lfsg;->a:Lfsg;

    .line 993
    .line 994
    iget v1, p0, Lbps;->a:I

    .line 995
    .line 996
    if-nez v1, :cond_2c

    .line 997
    .line 998
    invoke-static {p1}, Lcma;->bD(Ljava/lang/Object;)V

    .line 999
    .line 1000
    .line 1001
    iget-object p1, p0, Lbps;->b:Ljava/lang/Object;

    .line 1002
    .line 1003
    sget v1, Ldrv;->I:I

    .line 1004
    .line 1005
    move-object v1, p1

    .line 1006
    check-cast v1, Ldrv;

    .line 1007
    .line 1008
    iget-object v1, v1, Ldrv;->y:Lbag;

    .line 1009
    .line 1010
    iget-object v1, v1, Lbag;->b:Lgca;

    .line 1011
    .line 1012
    new-instance v2, Lazf;

    .line 1013
    .line 1014
    const/4 v3, 0x3

    .line 1015
    invoke-direct {v2, p1, v3}, Lazf;-><init>(Ljava/lang/Object;I)V

    .line 1016
    .line 1017
    .line 1018
    iput v4, p0, Lbps;->a:I

    .line 1019
    .line 1020
    invoke-interface {v1, v2, p0}, Lgca;->a(Lgbk;Lfrz;)Ljava/lang/Object;

    .line 1021
    .line 1022
    .line 1023
    move-result-object p0

    .line 1024
    if-ne p0, v0, :cond_2d

    .line 1025
    .line 1026
    return-object v0

    .line 1027
    :cond_2c
    invoke-static {p1}, Lcma;->bD(Ljava/lang/Object;)V

    .line 1028
    .line 1029
    .line 1030
    :cond_2d
    new-instance p0, Lfpu;

    .line 1031
    .line 1032
    invoke-direct {p0}, Lfpu;-><init>()V

    .line 1033
    .line 1034
    .line 1035
    throw p0

    .line 1036
    :pswitch_e
    sget-object v0, Lfsg;->a:Lfsg;

    .line 1037
    .line 1038
    iget v1, p0, Lbps;->a:I

    .line 1039
    .line 1040
    if-eqz v1, :cond_2e

    .line 1041
    .line 1042
    :try_start_3
    invoke-static {p1}, Lcma;->bD(Ljava/lang/Object;)V
    :try_end_3
    .catch Lbkt; {:try_start_3 .. :try_end_3} :catch_1
    .catch Ljava/util/concurrent/CancellationException; {:try_start_3 .. :try_end_3} :catch_2
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    .line 1043
    .line 1044
    .line 1045
    goto :goto_11

    .line 1046
    :catchall_1
    move-exception p1

    .line 1047
    goto :goto_12

    .line 1048
    :catch_1
    move-exception p1

    .line 1049
    goto :goto_13

    .line 1050
    :cond_2e
    invoke-static {p1}, Lcma;->bD(Ljava/lang/Object;)V

    .line 1051
    .line 1052
    .line 1053
    :try_start_4
    iget-object p1, p0, Lbps;->b:Ljava/lang/Object;

    .line 1054
    .line 1055
    move-object v1, p1

    .line 1056
    check-cast v1, Lblb;

    .line 1057
    .line 1058
    iget-object v1, v1, Lblb;->h:Lfyz;

    .line 1059
    .line 1060
    new-instance v2, Lahy;

    .line 1061
    .line 1062
    check-cast p1, Lblb;

    .line 1063
    .line 1064
    const/16 v5, 0x14

    .line 1065
    .line 1066
    invoke-direct {v2, p1, v3, v5}, Lahy;-><init>(Lblb;Lfrz;I)V

    .line 1067
    .line 1068
    .line 1069
    iput v4, p0, Lbps;->a:I

    .line 1070
    .line 1071
    invoke-static {v1, v2, p0}, Lfuu;->i(Lfse;Lftr;Lfrz;)Ljava/lang/Object;

    .line 1072
    .line 1073
    .line 1074
    move-result-object p1

    .line 1075
    if-ne p1, v0, :cond_2f

    .line 1076
    .line 1077
    return-object v0

    .line 1078
    :cond_2f
    :goto_11
    check-cast p1, Lbgb;
    :try_end_4
    .catch Lbkt; {:try_start_4 .. :try_end_4} :catch_1
    .catch Ljava/util/concurrent/CancellationException; {:try_start_4 .. :try_end_4} :catch_2
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    .line 1079
    .line 1080
    goto :goto_14

    .line 1081
    :goto_12
    sget-object v0, Lbld;->a:Ljava/lang/String;

    .line 1082
    .line 1083
    invoke-static {}, Lbiu;->a()Lbiu;

    .line 1084
    .line 1085
    .line 1086
    const-string v1, "Unexpected error in WorkerWrapper"

    .line 1087
    .line 1088
    invoke-static {v0, v1, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 1089
    .line 1090
    .line 1091
    new-instance p1, Lbkv;

    .line 1092
    .line 1093
    invoke-direct {p1, v3}, Lbkv;-><init>([B)V

    .line 1094
    .line 1095
    .line 1096
    goto :goto_14

    .line 1097
    :catch_2
    new-instance p1, Lbkv;

    .line 1098
    .line 1099
    invoke-direct {p1, v3}, Lbkv;-><init>([B)V

    .line 1100
    .line 1101
    .line 1102
    goto :goto_14

    .line 1103
    :goto_13
    new-instance v0, Lbkx;

    .line 1104
    .line 1105
    iget p1, p1, Lbkt;->a:I

    .line 1106
    .line 1107
    invoke-direct {v0, p1}, Lbkx;-><init>(I)V

    .line 1108
    .line 1109
    .line 1110
    move-object p1, v0

    .line 1111
    :goto_14
    iget-object p0, p0, Lbps;->b:Ljava/lang/Object;

    .line 1112
    .line 1113
    new-instance v0, Lbky;

    .line 1114
    .line 1115
    check-cast p0, Lblb;

    .line 1116
    .line 1117
    invoke-direct {v0, p1, p0}, Lbky;-><init>(Lbgb;Lblb;)V

    .line 1118
    .line 1119
    .line 1120
    iget-object p0, p0, Lblb;->d:Landroidx/work/impl/WorkDatabase;

    .line 1121
    .line 1122
    invoke-virtual {p0, v0}, Laig;->e(Ljava/util/concurrent/Callable;)Ljava/lang/Object;

    .line 1123
    .line 1124
    .line 1125
    move-result-object p0

    .line 1126
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1127
    .line 1128
    .line 1129
    return-object p0

    .line 1130
    :pswitch_f
    sget-object v0, Lfsg;->a:Lfsg;

    .line 1131
    .line 1132
    iget v1, p0, Lbps;->a:I

    .line 1133
    .line 1134
    if-eqz v1, :cond_30

    .line 1135
    .line 1136
    invoke-static {p1}, Lcma;->bD(Ljava/lang/Object;)V

    .line 1137
    .line 1138
    .line 1139
    return-object p1

    .line 1140
    :cond_30
    invoke-static {p1}, Lcma;->bD(Ljava/lang/Object;)V

    .line 1141
    .line 1142
    .line 1143
    iget-object p1, p0, Lbps;->b:Ljava/lang/Object;

    .line 1144
    .line 1145
    iput v4, p0, Lbps;->a:I

    .line 1146
    .line 1147
    check-cast p1, Landroidx/work/impl/workers/ConstraintTrackingWorker;

    .line 1148
    .line 1149
    invoke-virtual {p1, p0}, Landroidx/work/impl/workers/ConstraintTrackingWorker;->g(Lfrz;)Ljava/lang/Object;

    .line 1150
    .line 1151
    .line 1152
    move-result-object p0

    .line 1153
    if-ne p0, v0, :cond_31

    .line 1154
    .line 1155
    return-object v0

    .line 1156
    :cond_31
    return-object p0

    .line 1157
    :cond_32
    iget-object p1, p0, Lbps;->b:Ljava/lang/Object;

    .line 1158
    .line 1159
    iput v4, p0, Lbps;->a:I

    .line 1160
    .line 1161
    sget-object v1, Lgcu;->a:Lgcu;

    .line 1162
    .line 1163
    invoke-interface {p1, v1, p0}, Lgbj;->a(Lgbk;Lfrz;)Ljava/lang/Object;

    .line 1164
    .line 1165
    .line 1166
    move-result-object p0

    .line 1167
    if-eq p0, v0, :cond_33

    .line 1168
    .line 1169
    sget-object p0, Lfqj;->a:Lfqj;

    .line 1170
    .line 1171
    :cond_33
    if-ne p0, v0, :cond_34

    .line 1172
    .line 1173
    return-object v0

    .line 1174
    :cond_34
    :goto_15
    sget-object p0, Lfqj;->a:Lfqj;

    .line 1175
    .line 1176
    return-object p0

    .line 1177
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
    .line 1178
    .line 1179
    .line 1180
    .line 1181
    .line 1182
    .line 1183
    .line 1184
    .line 1185
    .line 1186
    .line 1187
    .line 1188
    .line 1189
    .line 1190
    .line 1191
    .line 1192
    .line 1193
    .line 1194
    .line 1195
    .line 1196
    .line 1197
    .line 1198
    .line 1199
    .line 1200
    .line 1201
    .line 1202
    .line 1203
    .line 1204
    .line 1205
    .line 1206
    .line 1207
    .line 1208
    .line 1209
    .line 1210
    .line 1211
    .line 1212
    .line 1213
    .line 1214
    .line 1215
    .line 1216
    .line 1217
    .line 1218
    .line 1219
    .line 1220
    .line 1221
    .line 1222
    .line 1223
    .line 1224
    .line 1225
    .line 1226
    .line 1227
    .line 1228
    .line 1229
    .line 1230
    .line 1231
    .line 1232
    .line 1233
    .line 1234
    .line 1235
    .line 1236
    .line 1237
    .line 1238
    .line 1239
    .line 1240
    .line 1241
    .line 1242
    .line 1243
    .line 1244
    .line 1245
    .line 1246
    .line 1247
    .line 1248
    .line 1249
    .line 1250
    .line 1251
    .line 1252
    .line 1253
    .line 1254
    .line 1255
    .line 1256
    .line 1257
    .line 1258
    .line 1259
    .line 1260
    .line 1261
    .line 1262
    .line 1263
    .line 1264
    .line 1265
    .line 1266
    .line 1267
    .line 1268
    .line 1269
    .line 1270
    .line 1271
    .line 1272
    .line 1273
    .line 1274
    .line 1275
    .line 1276
    .line 1277
    .line 1278
    .line 1279
    .line 1280
    .line 1281
    .line 1282
    .line 1283
    .line 1284
    .line 1285
    .line 1286
    .line 1287
    .line 1288
    .line 1289
    .line 1290
    .line 1291
    .line 1292
    .line 1293
    .line 1294
    .line 1295
    .line 1296
    .line 1297
    .line 1298
    .line 1299
    .line 1300
    .line 1301
    .line 1302
    .line 1303
    .line 1304
    .line 1305
    .line 1306
    .line 1307
    .line 1308
    .line 1309
    .line 1310
    .line 1311
    .line 1312
    .line 1313
    .line 1314
    .line 1315
    .line 1316
    .line 1317
    .line 1318
    .line 1319
    .line 1320
    .line 1321
    .line 1322
    .line 1323
    .line 1324
    .line 1325
    .line 1326
    .line 1327
    .line 1328
    .line 1329
    .line 1330
    .line 1331
    .line 1332
    .line 1333
    .line 1334
    .line 1335
    .line 1336
    .line 1337
    .line 1338
    .line 1339
    .line 1340
    .line 1341
    .line 1342
    .line 1343
    .line 1344
    .line 1345
    .line 1346
    .line 1347
    .line 1348
    .line 1349
    .line 1350
    .line 1351
    .line 1352
    .line 1353
    .line 1354
    .line 1355
    .line 1356
    .line 1357
    .line 1358
    .line 1359
    .line 1360
    .line 1361
    .line 1362
    .line 1363
    .line 1364
    .line 1365
    .line 1366
    .line 1367
    .line 1368
    .line 1369
    .line 1370
    .line 1371
    .line 1372
    .line 1373
    .line 1374
    .line 1375
    .line 1376
    .line 1377
    .line 1378
    .line 1379
    .line 1380
    .line 1381
    .line 1382
    .line 1383
    .line 1384
    .line 1385
    .line 1386
    .line 1387
    .line 1388
    .line 1389
    .line 1390
    .line 1391
    .line 1392
    .line 1393
    .line 1394
    .line 1395
    .line 1396
    .line 1397
    .line 1398
    .line 1399
    .line 1400
    .line 1401
    .line 1402
    .line 1403
    .line 1404
    .line 1405
    .line 1406
    .line 1407
    .line 1408
    .line 1409
    .line 1410
    .line 1411
    .line 1412
    .line 1413
    .line 1414
    .line 1415
    .line 1416
    .line 1417
    .line 1418
    .line 1419
    .line 1420
    .line 1421
    .line 1422
    .line 1423
    .line 1424
    .line 1425
    .line 1426
    .line 1427
    .line 1428
    .line 1429
    .line 1430
    .line 1431
    .line 1432
    .line 1433
    .line 1434
    .line 1435
    .line 1436
    .line 1437
    .line 1438
    .line 1439
    .line 1440
    .line 1441
    .line 1442
    .line 1443
    .line 1444
    .line 1445
    .line 1446
    .line 1447
    .line 1448
    .line 1449
    .line 1450
    .line 1451
    .line 1452
    .line 1453
    .line 1454
    .line 1455
    .line 1456
    .line 1457
    .line 1458
    .line 1459
    .line 1460
    .line 1461
    .line 1462
    .line 1463
    .line 1464
    .line 1465
    .line 1466
    .line 1467
    .line 1468
    .line 1469
    .line 1470
    .line 1471
    .line 1472
    .line 1473
    .line 1474
    .line 1475
    .line 1476
    .line 1477
    .line 1478
    .line 1479
    .line 1480
    .line 1481
    .line 1482
    .line 1483
    .line 1484
    .line 1485
    .line 1486
    .line 1487
    .line 1488
    .line 1489
    .line 1490
    .line 1491
    .line 1492
    .line 1493
    .line 1494
    .line 1495
    .line 1496
    .line 1497
    .line 1498
    .line 1499
    .line 1500
    .line 1501
    .line 1502
    .line 1503
    .line 1504
    .line 1505
    .line 1506
    .line 1507
    .line 1508
    .line 1509
    .line 1510
    .line 1511
    .line 1512
    .line 1513
    .line 1514
    .line 1515
    .line 1516
    .line 1517
    .line 1518
    .line 1519
    .line 1520
    .line 1521
    .line 1522
    .line 1523
    .line 1524
    .line 1525
    .line 1526
    .line 1527
    .line 1528
    .line 1529
    .line 1530
    .line 1531
    .line 1532
    .line 1533
    .line 1534
    .line 1535
    .line 1536
    .line 1537
    .line 1538
    .line 1539
    .line 1540
    .line 1541
    .line 1542
    .line 1543
    .line 1544
    .line 1545
    .line 1546
    .line 1547
    .line 1548
    .line 1549
    .line 1550
    .line 1551
    .line 1552
    .line 1553
    .line 1554
    .line 1555
    .line 1556
    .line 1557
    .line 1558
    .line 1559
    .line 1560
    .line 1561
    .line 1562
    .line 1563
    .line 1564
    .line 1565
    .line 1566
    .line 1567
    .line 1568
    .line 1569
    .line 1570
    .line 1571
    .line 1572
    .line 1573
    .line 1574
    .line 1575
    .line 1576
    .line 1577
    .line 1578
    .line 1579
    .line 1580
    .line 1581
    .line 1582
    .line 1583
    .line 1584
    .line 1585
    .line 1586
    .line 1587
    .line 1588
    .line 1589
    .line 1590
    .line 1591
    .line 1592
    .line 1593
    .line 1594
    .line 1595
    .line 1596
    .line 1597
    .line 1598
    .line 1599
    .line 1600
    .line 1601
    .line 1602
    .line 1603
    .line 1604
    .line 1605
    .line 1606
    .line 1607
    .line 1608
    .line 1609
    .line 1610
    .line 1611
    .line 1612
    .line 1613
    .line 1614
    .line 1615
    .line 1616
    .line 1617
    .line 1618
    .line 1619
    .line 1620
    .line 1621
    .line 1622
    .line 1623
    .line 1624
    .line 1625
    .line 1626
    .line 1627
    .line 1628
    .line 1629
    .line 1630
    .line 1631
    .line 1632
    .line 1633
    .line 1634
    .line 1635
    .line 1636
    .line 1637
    .line 1638
    .line 1639
    .line 1640
    .line 1641
    .line 1642
    .line 1643
    .line 1644
    .line 1645
    .line 1646
    .line 1647
    .line 1648
    .line 1649
    .line 1650
    .line 1651
    .line 1652
    .line 1653
    .line 1654
    .line 1655
    .line 1656
    .line 1657
    .line 1658
    .line 1659
    .line 1660
    .line 1661
    .line 1662
    .line 1663
    .line 1664
    .line 1665
    .line 1666
    .line 1667
    .line 1668
    .line 1669
    .line 1670
    .line 1671
    .line 1672
    .line 1673
    .line 1674
    .line 1675
    .line 1676
    .line 1677
    .line 1678
    .line 1679
    .line 1680
    .line 1681
    .line 1682
    .line 1683
    .line 1684
    .line 1685
    .line 1686
    .line 1687
    .line 1688
    .line 1689
    .line 1690
    .line 1691
    .line 1692
    .line 1693
    .line 1694
    .line 1695
    .line 1696
    .line 1697
    .line 1698
    .line 1699
    .line 1700
    .line 1701
    .line 1702
    .line 1703
    .line 1704
    .line 1705
    .line 1706
    .line 1707
    .line 1708
    .line 1709
    .line 1710
    .line 1711
    .line 1712
    .line 1713
    .line 1714
    .line 1715
    .line 1716
    .line 1717
    .line 1718
    .line 1719
    .line 1720
    .line 1721
    .line 1722
    .line 1723
    .line 1724
    .line 1725
    .line 1726
    .line 1727
    .line 1728
    .line 1729
    .line 1730
    .line 1731
    .line 1732
    .line 1733
    .line 1734
    .line 1735
    .line 1736
    .line 1737
    .line 1738
    .line 1739
    .line 1740
    .line 1741
    .line 1742
    .line 1743
    .line 1744
    .line 1745
    .line 1746
    .line 1747
    .line 1748
    .line 1749
    .line 1750
    .line 1751
    .line 1752
    .line 1753
    .line 1754
    .line 1755
    .line 1756
    .line 1757
    .line 1758
    .line 1759
    .line 1760
    .line 1761
    .line 1762
    .line 1763
    .line 1764
    .line 1765
    .line 1766
    .line 1767
    .line 1768
    .line 1769
    .line 1770
    .line 1771
    .line 1772
    .line 1773
    .line 1774
    .line 1775
    .line 1776
    .line 1777
    .line 1778
    .line 1779
    .line 1780
    .line 1781
    .line 1782
    .line 1783
    .line 1784
    .line 1785
    .line 1786
    .line 1787
    .line 1788
    .line 1789
    .line 1790
    .line 1791
    .line 1792
    .line 1793
    .line 1794
    .line 1795
    .line 1796
    .line 1797
    .line 1798
    .line 1799
    .line 1800
    .line 1801
    .line 1802
    .line 1803
    .line 1804
    .line 1805
    .line 1806
    .line 1807
    .line 1808
    .line 1809
    .line 1810
    .line 1811
    .line 1812
    .line 1813
    .line 1814
    .line 1815
    .line 1816
    .line 1817
    .line 1818
    .line 1819
    .line 1820
    .line 1821
    .line 1822
    .line 1823
    .line 1824
    .line 1825
    .line 1826
    .line 1827
    .line 1828
    .line 1829
    .line 1830
    .line 1831
    .line 1832
    .line 1833
    .line 1834
    .line 1835
    .line 1836
    .line 1837
    .line 1838
    .line 1839
    .line 1840
    .line 1841
    .line 1842
    .line 1843
    .line 1844
    .line 1845
    .line 1846
    .line 1847
    .line 1848
    .line 1849
    .line 1850
    .line 1851
    .line 1852
    .line 1853
    .line 1854
    .line 1855
    .line 1856
    .line 1857
    .line 1858
    .line 1859
    .line 1860
    .line 1861
    .line 1862
    .line 1863
    .line 1864
    .line 1865
    .line 1866
    .line 1867
    .line 1868
    .line 1869
    .line 1870
    .line 1871
    .line 1872
    .line 1873
    .line 1874
    .line 1875
    .line 1876
    .line 1877
    .line 1878
    .line 1879
    .line 1880
    .line 1881
    .line 1882
    .line 1883
    .line 1884
    .line 1885
    .line 1886
    .line 1887
    .line 1888
    .line 1889
    .line 1890
    .line 1891
    .line 1892
    .line 1893
    .line 1894
    .line 1895
    .line 1896
    .line 1897
    .line 1898
    .line 1899
    .line 1900
    .line 1901
    .line 1902
    .line 1903
    .line 1904
    .line 1905
    .line 1906
    .line 1907
    .line 1908
    .line 1909
    .line 1910
    .line 1911
    .line 1912
    .line 1913
    .line 1914
    .line 1915
    .line 1916
    .line 1917
    .line 1918
    .line 1919
    .line 1920
    .line 1921
    .line 1922
    .line 1923
    .line 1924
    .line 1925
    .line 1926
    .line 1927
    .line 1928
    .line 1929
    .line 1930
    .line 1931
    .line 1932
    .line 1933
    .line 1934
    .line 1935
    .line 1936
    .line 1937
    .line 1938
    .line 1939
    .line 1940
    .line 1941
    .line 1942
    .line 1943
    .line 1944
    .line 1945
    .line 1946
    .line 1947
    .line 1948
    .line 1949
    .line 1950
    .line 1951
    .line 1952
    .line 1953
    .line 1954
    .line 1955
    .line 1956
    .line 1957
    .line 1958
    .line 1959
    .line 1960
    .line 1961
    .line 1962
    .line 1963
    .line 1964
    .line 1965
    .line 1966
    .line 1967
    .line 1968
    .line 1969
    .line 1970
    .line 1971
    .line 1972
    .line 1973
    .line 1974
    .line 1975
    .line 1976
    .line 1977
    .line 1978
    .line 1979
    .line 1980
    .line 1981
    .line 1982
    .line 1983
    .line 1984
    .line 1985
    .line 1986
    .line 1987
    .line 1988
    .line 1989
    .line 1990
    .line 1991
    .line 1992
    .line 1993
    .line 1994
    .line 1995
    .line 1996
    .line 1997
    .line 1998
    .line 1999
    .line 2000
    .line 2001
    .line 2002
    .line 2003
    .line 2004
    .line 2005
    .line 2006
    .line 2007
    .line 2008
    .line 2009
    .line 2010
    .line 2011
    .line 2012
    .line 2013
    .line 2014
    .line 2015
    .line 2016
    .line 2017
    .line 2018
    .line 2019
    .line 2020
    .line 2021
    .line 2022
    .line 2023
    .line 2024
    .line 2025
    .line 2026
    .line 2027
    .line 2028
    .line 2029
    .line 2030
    .line 2031
    .line 2032
    .line 2033
    .line 2034
    .line 2035
    .line 2036
    .line 2037
    .line 2038
    .line 2039
    .line 2040
    .line 2041
    .line 2042
    .line 2043
    .line 2044
    .line 2045
    .line 2046
    .line 2047
    .line 2048
    .line 2049
    .line 2050
    .line 2051
    .line 2052
    .line 2053
    .line 2054
    .line 2055
    .line 2056
    .line 2057
    .line 2058
    .line 2059
    .line 2060
    .line 2061
    .line 2062
    .line 2063
    .line 2064
    .line 2065
    .line 2066
    .line 2067
    .line 2068
    .line 2069
    .line 2070
    .line 2071
    .line 2072
    .line 2073
    .line 2074
    .line 2075
    .line 2076
    .line 2077
    .line 2078
    .line 2079
    .line 2080
    .line 2081
    .line 2082
    .line 2083
    .line 2084
    .line 2085
    .line 2086
    .line 2087
    .line 2088
    .line 2089
    .line 2090
    .line 2091
    .line 2092
    .line 2093
    .line 2094
    .line 2095
    .line 2096
    .line 2097
    .line 2098
    .line 2099
    .line 2100
    .line 2101
    .line 2102
    .line 2103
    .line 2104
    .line 2105
    .line 2106
    .line 2107
    .line 2108
    .line 2109
    .line 2110
    .line 2111
    .line 2112
    .line 2113
    .line 2114
    .line 2115
    .line 2116
    .line 2117
    .line 2118
    .line 2119
    .line 2120
    .line 2121
    .line 2122
    .line 2123
    .line 2124
    .line 2125
    .line 2126
    .line 2127
    .line 2128
    .line 2129
    .line 2130
    .line 2131
    .line 2132
    .line 2133
    .line 2134
    .line 2135
    .line 2136
    .line 2137
    .line 2138
    .line 2139
    .line 2140
    .line 2141
    .line 2142
    .line 2143
    .line 2144
    .line 2145
    .line 2146
    .line 2147
    .line 2148
    .line 2149
    .line 2150
    .line 2151
    .line 2152
    .line 2153
    .line 2154
    .line 2155
    .line 2156
.end method

.method public final b(Ljava/lang/Object;Lfrz;)Lfrz;
    .locals 2

    .line 1
    iget p1, p0, Lbps;->c:I

    .line 2
    .line 3
    const/4 v0, 0x0

    .line 4
    packed-switch p1, :pswitch_data_0

    .line 5
    .line 6
    .line 7
    new-instance p1, Lbps;

    .line 8
    .line 9
    iget-object p0, p0, Lbps;->b:Ljava/lang/Object;

    .line 10
    .line 11
    const/16 v0, 0x10

    .line 12
    .line 13
    invoke-direct {p1, p0, p2, v0}, Lbps;-><init>(Lgbj;Lfrz;I)V

    .line 14
    .line 15
    .line 16
    return-object p1

    .line 17
    :pswitch_0
    iget-object p0, p0, Lbps;->b:Ljava/lang/Object;

    .line 18
    .line 19
    new-instance p1, Lbps;

    .line 20
    .line 21
    check-cast p0, Lekq;

    .line 22
    .line 23
    const/16 v0, 0xf

    .line 24
    .line 25
    invoke-direct {p1, p0, p2, v0}, Lbps;-><init>(Lekq;Lfrz;I)V

    .line 26
    .line 27
    .line 28
    return-object p1

    .line 29
    :pswitch_1
    iget-object p0, p0, Lbps;->b:Ljava/lang/Object;

    .line 30
    .line 31
    new-instance p1, Lbps;

    .line 32
    .line 33
    check-cast p0, Lejm;

    .line 34
    .line 35
    const/16 v1, 0xe

    .line 36
    .line 37
    invoke-direct {p1, p0, p2, v1, v0}, Lbps;-><init>(Lejm;Lfrz;I[C)V

    .line 38
    .line 39
    .line 40
    return-object p1

    .line 41
    :pswitch_2
    iget-object p0, p0, Lbps;->b:Ljava/lang/Object;

    .line 42
    .line 43
    new-instance p1, Lbps;

    .line 44
    .line 45
    check-cast p0, Lejm;

    .line 46
    .line 47
    const/16 v1, 0xd

    .line 48
    .line 49
    invoke-direct {p1, p0, p2, v1, v0}, Lbps;-><init>(Lejm;Lfrz;I[B)V

    .line 50
    .line 51
    .line 52
    return-object p1

    .line 53
    :pswitch_3
    iget-object p0, p0, Lbps;->b:Ljava/lang/Object;

    .line 54
    .line 55
    new-instance p1, Lbps;

    .line 56
    .line 57
    check-cast p0, Lejm;

    .line 58
    .line 59
    const/16 v0, 0xc

    .line 60
    .line 61
    invoke-direct {p1, p0, p2, v0}, Lbps;-><init>(Lejm;Lfrz;I)V

    .line 62
    .line 63
    .line 64
    return-object p1

    .line 65
    :pswitch_4
    iget-object p0, p0, Lbps;->b:Ljava/lang/Object;

    .line 66
    .line 67
    new-instance p1, Lbps;

    .line 68
    .line 69
    check-cast p0, Lejd;

    .line 70
    .line 71
    const/16 v0, 0xb

    .line 72
    .line 73
    invoke-direct {p1, p0, p2, v0}, Lbps;-><init>(Lejd;Lfrz;I)V

    .line 74
    .line 75
    .line 76
    return-object p1

    .line 77
    :pswitch_5
    iget-object p0, p0, Lbps;->b:Ljava/lang/Object;

    .line 78
    .line 79
    new-instance p1, Lbps;

    .line 80
    .line 81
    check-cast p0, Leif;

    .line 82
    .line 83
    const/16 v1, 0xa

    .line 84
    .line 85
    invoke-direct {p1, p0, p2, v1, v0}, Lbps;-><init>(Leif;Lfrz;I[C)V

    .line 86
    .line 87
    .line 88
    return-object p1

    .line 89
    :pswitch_6
    iget-object p0, p0, Lbps;->b:Ljava/lang/Object;

    .line 90
    .line 91
    new-instance p1, Lbps;

    .line 92
    .line 93
    check-cast p0, Leif;

    .line 94
    .line 95
    const/16 v1, 0x9

    .line 96
    .line 97
    invoke-direct {p1, p0, p2, v1, v0}, Lbps;-><init>(Leif;Lfrz;I[B)V

    .line 98
    .line 99
    .line 100
    return-object p1

    .line 101
    :pswitch_7
    iget-object p0, p0, Lbps;->b:Ljava/lang/Object;

    .line 102
    .line 103
    new-instance p1, Lbps;

    .line 104
    .line 105
    check-cast p0, Leif;

    .line 106
    .line 107
    const/16 v0, 0x8

    .line 108
    .line 109
    invoke-direct {p1, p0, p2, v0}, Lbps;-><init>(Leif;Lfrz;I)V

    .line 110
    .line 111
    .line 112
    return-object p1

    .line 113
    :pswitch_8
    iget-object p0, p0, Lbps;->b:Ljava/lang/Object;

    .line 114
    .line 115
    new-instance p1, Lbps;

    .line 116
    .line 117
    check-cast p0, Lcom/google/android/wearable/watchface/koru/artsandculture/datastore/scheduler/FetchFutureArtworkSchedulerService;

    .line 118
    .line 119
    const/4 v0, 0x7

    .line 120
    invoke-direct {p1, p0, p2, v0}, Lbps;-><init>(Lcom/google/android/wearable/watchface/koru/artsandculture/datastore/scheduler/FetchFutureArtworkSchedulerService;Lfrz;I)V

    .line 121
    .line 122
    .line 123
    return-object p1

    .line 124
    :pswitch_9
    new-instance p1, Lbps;

    .line 125
    .line 126
    iget-object p0, p0, Lbps;->b:Ljava/lang/Object;

    .line 127
    .line 128
    const/4 v0, 0x6

    .line 129
    invoke-direct {p1, p0, p2, v0}, Lbps;-><init>(Lfcy;Lfrz;I)V

    .line 130
    .line 131
    .line 132
    return-object p1

    .line 133
    :pswitch_a
    iget-object p0, p0, Lbps;->b:Ljava/lang/Object;

    .line 134
    .line 135
    new-instance p1, Lbps;

    .line 136
    .line 137
    check-cast p0, Lcom/google/android/wearable/watchface/koru/artsandculture/ArtsAndCultureWatchFaceService;

    .line 138
    .line 139
    const/4 v1, 0x5

    .line 140
    invoke-direct {p1, p0, p2, v1, v0}, Lbps;-><init>(Lcom/google/android/wearable/watchface/koru/artsandculture/ArtsAndCultureWatchFaceService;Lfrz;I[B)V

    .line 141
    .line 142
    .line 143
    return-object p1

    .line 144
    :pswitch_b
    iget-object p0, p0, Lbps;->b:Ljava/lang/Object;

    .line 145
    .line 146
    new-instance p1, Lbps;

    .line 147
    .line 148
    check-cast p0, Lcom/google/android/wearable/watchface/koru/artsandculture/ArtsAndCultureWatchFaceService;

    .line 149
    .line 150
    const/4 v0, 0x4

    .line 151
    invoke-direct {p1, p0, p2, v0}, Lbps;-><init>(Lcom/google/android/wearable/watchface/koru/artsandculture/ArtsAndCultureWatchFaceService;Lfrz;I)V

    .line 152
    .line 153
    .line 154
    return-object p1

    .line 155
    :pswitch_c
    iget-object p0, p0, Lbps;->b:Ljava/lang/Object;

    .line 156
    .line 157
    new-instance p1, Lbps;

    .line 158
    .line 159
    check-cast p0, Ldrv;

    .line 160
    .line 161
    const/4 v1, 0x3

    .line 162
    invoke-direct {p1, p0, p2, v1, v0}, Lbps;-><init>(Ldrv;Lfrz;I[B)V

    .line 163
    .line 164
    .line 165
    return-object p1

    .line 166
    :pswitch_d
    iget-object p0, p0, Lbps;->b:Ljava/lang/Object;

    .line 167
    .line 168
    new-instance p1, Lbps;

    .line 169
    .line 170
    check-cast p0, Ldrv;

    .line 171
    .line 172
    const/4 v0, 0x2

    .line 173
    invoke-direct {p1, p0, p2, v0}, Lbps;-><init>(Ldrv;Lfrz;I)V

    .line 174
    .line 175
    .line 176
    return-object p1

    .line 177
    :pswitch_e
    iget-object p0, p0, Lbps;->b:Ljava/lang/Object;

    .line 178
    .line 179
    new-instance p1, Lbps;

    .line 180
    .line 181
    check-cast p0, Lblb;

    .line 182
    .line 183
    const/4 v0, 0x1

    .line 184
    invoke-direct {p1, p0, p2, v0}, Lbps;-><init>(Lblb;Lfrz;I)V

    .line 185
    .line 186
    .line 187
    return-object p1

    .line 188
    :pswitch_f
    iget-object p0, p0, Lbps;->b:Ljava/lang/Object;

    .line 189
    .line 190
    new-instance p1, Lbps;

    .line 191
    .line 192
    check-cast p0, Landroidx/work/impl/workers/ConstraintTrackingWorker;

    .line 193
    .line 194
    const/4 v0, 0x0

    .line 195
    invoke-direct {p1, p0, p2, v0}, Lbps;-><init>(Landroidx/work/impl/workers/ConstraintTrackingWorker;Lfrz;I)V

    .line 196
    .line 197
    .line 198
    return-object p1

    .line 199
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
    .line 200
    .line 201
    .line 202
    .line 203
    .line 204
    .line 205
    .line 206
    .line 207
    .line 208
    .line 209
    .line 210
    .line 211
    .line 212
    .line 213
    .line 214
    .line 215
    .line 216
    .line 217
    .line 218
    .line 219
    .line 220
    .line 221
    .line 222
    .line 223
    .line 224
    .line 225
    .line 226
    .line 227
    .line 228
    .line 229
    .line 230
    .line 231
    .line 232
    .line 233
    .line 234
    .line 235
    .line 236
    .line 237
    .line 238
    .line 239
    .line 240
    .line 241
    .line 242
    .line 243
    .line 244
    .line 245
    .line 246
    .line 247
    .line 248
    .line 249
    .line 250
    .line 251
    .line 252
    .line 253
    .line 254
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
    .line 261
    .line 262
    .line 263
    .line 264
    .line 265
    .line 266
    .line 267
    .line 268
    .line 269
    .line 270
    .line 271
    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    .line 277
    .line 278
    .line 279
    .line 280
    .line 281
    .line 282
    .line 283
    .line 284
    .line 285
    .line 286
    .line 287
    .line 288
    .line 289
    .line 290
    .line 291
    .line 292
    .line 293
    .line 294
    .line 295
    .line 296
    .line 297
    .line 298
    .line 299
    .line 300
    .line 301
    .line 302
    .line 303
    .line 304
    .line 305
    .line 306
    .line 307
    .line 308
    .line 309
    .line 310
    .line 311
    .line 312
    .line 313
    .line 314
    .line 315
.end method
