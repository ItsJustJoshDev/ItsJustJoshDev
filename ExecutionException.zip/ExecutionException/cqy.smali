.class public final Lcqy;
.super Lcsg;
.source "PG"

# interfaces
.implements Lcpw;


# static fields
.field public static final synthetic a:I


# direct methods
.method static constructor <clinit>()V
    .locals 2

    .line 1
    new-instance v0, Ljava/util/concurrent/atomic/AtomicBoolean;

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    invoke-direct {v0, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    .line 5
    .line 6
    .line 7
    return-void
    .line 8
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .locals 4

    .line 1
    sget-object v0, Lcpv;->l:Ldhp;

    .line 2
    .line 3
    sget-object v1, Lcsc;->a:Lcsb;

    .line 4
    .line 5
    new-instance v2, Lfdk;

    .line 6
    .line 7
    const/4 v3, 0x0

    .line 8
    invoke-direct {v2, v3}, Lfdk;-><init>([C)V

    .line 9
    .line 10
    .line 11
    new-instance v3, Lcma;

    .line 12
    .line 13
    invoke-direct {v3}, Lcma;-><init>()V

    .line 14
    .line 15
    .line 16
    iput-object v3, v2, Lfdk;->b:Ljava/lang/Object;

    .line 17
    .line 18
    invoke-virtual {v2}, Lfdk;->h()Lcsf;

    .line 19
    .line 20
    .line 21
    move-result-object v2

    .line 22
    invoke-direct {p0, p1, v0, v1, v2}, Lcsg;-><init>(Landroid/content/Context;Ldhp;Lcsc;Lcsf;)V

    .line 23
    .line 24
    .line 25
    return-void
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
.end method


# virtual methods
.method public final a(Ljava/util/concurrent/TimeUnit;)V
    .locals 3

    .line 1
    new-instance v0, Lcqu;

    .line 2
    .line 3
    invoke-direct {v0}, Lcqu;-><init>()V

    .line 4
    .line 5
    .line 6
    invoke-virtual {p0, v0}, Lcsg;->e(Lctz;)Lcxu;

    .line 7
    .line 8
    .line 9
    move-result-object p0

    .line 10
    :try_start_0
    const-string v0, "Must not be called on the main application thread"

    .line 11
    .line 12
    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    .line 13
    .line 14
    .line 15
    move-result-object v1

    .line 16
    invoke-static {}, Landroid/os/Looper;->myLooper()Landroid/os/Looper;

    .line 17
    .line 18
    .line 19
    move-result-object v2

    .line 20
    if-eq v1, v2, :cond_4

    .line 21
    .line 22
    const-string v0, "Must not be called on GoogleApiHandler thread."

    .line 23
    .line 24
    invoke-static {}, Landroid/os/Looper;->myLooper()Landroid/os/Looper;

    .line 25
    .line 26
    .line 27
    move-result-object v1

    .line 28
    if-eqz v1, :cond_1

    .line 29
    .line 30
    invoke-virtual {v1}, Landroid/os/Looper;->getThread()Ljava/lang/Thread;

    .line 31
    .line 32
    .line 33
    move-result-object v1

    .line 34
    invoke-virtual {v1}, Ljava/lang/Thread;->getName()Ljava/lang/String;

    .line 35
    .line 36
    .line 37
    move-result-object v1

    .line 38
    const-string v2, "GoogleApiHandler"

    .line 39
    .line 40
    invoke-static {v1, v2}, Lj$/util/Objects;->equals(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 41
    .line 42
    .line 43
    move-result v1

    .line 44
    if-nez v1, :cond_0

    .line 45
    .line 46
    goto :goto_0

    .line 47
    :cond_0
    new-instance p0, Ljava/lang/IllegalStateException;

    .line 48
    .line 49
    invoke-direct {p0, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 50
    .line 51
    .line 52
    throw p0

    .line 53
    :cond_1
    :goto_0
    const-string v0, "TimeUnit must not be null"

    .line 54
    .line 55
    invoke-static {p1, v0}, Lcvv;->Z(Ljava/lang/Object;Ljava/lang/Object;)V

    .line 56
    .line 57
    .line 58
    invoke-virtual {p0}, Lcxu;->d()Z

    .line 59
    .line 60
    .line 61
    move-result v0

    .line 62
    if-eqz v0, :cond_2

    .line 63
    .line 64
    invoke-static {p0}, Lcvv;->ac(Lcxu;)V

    .line 65
    .line 66
    .line 67
    return-void

    .line 68
    :cond_2
    new-instance v0, Lcxz;

    .line 69
    .line 70
    invoke-direct {v0}, Lcxz;-><init>()V

    .line 71
    .line 72
    .line 73
    sget-object v1, Lcxx;->b:Ljava/util/concurrent/Executor;

    .line 74
    .line 75
    invoke-virtual {p0, v1, v0}, Lcxu;->i(Ljava/util/concurrent/Executor;Lcxs;)V

    .line 76
    .line 77
    .line 78
    sget-object v1, Lcxx;->b:Ljava/util/concurrent/Executor;

    .line 79
    .line 80
    invoke-virtual {p0, v1, v0}, Lcxu;->h(Ljava/util/concurrent/Executor;Lcxr;)V

    .line 81
    .line 82
    .line 83
    invoke-virtual {p0, v1, v0}, Lcxu;->f(Ljava/util/concurrent/Executor;Lcxp;)V

    .line 84
    .line 85
    .line 86
    iget-object v0, v0, Lcxz;->a:Ljava/util/concurrent/CountDownLatch;

    .line 87
    .line 88
    const-wide/16 v1, 0xa

    .line 89
    .line 90
    invoke-virtual {v0, v1, v2, p1}, Ljava/util/concurrent/CountDownLatch;->await(JLjava/util/concurrent/TimeUnit;)Z

    .line 91
    .line 92
    .line 93
    move-result p1

    .line 94
    if-eqz p1, :cond_3

    .line 95
    .line 96
    invoke-static {p0}, Lcvv;->ac(Lcxu;)V

    .line 97
    .line 98
    .line 99
    return-void

    .line 100
    :cond_3
    new-instance p0, Ljava/util/concurrent/TimeoutException;

    .line 101
    .line 102
    const-string p1, "Timed out waiting for Task"

    .line 103
    .line 104
    invoke-direct {p0, p1}, Ljava/util/concurrent/TimeoutException;-><init>(Ljava/lang/String;)V

    .line 105
    .line 106
    .line 107
    throw p0

    .line 108
    :cond_4
    new-instance p0, Ljava/lang/IllegalStateException;

    .line 109
    .line 110
    invoke-direct {p0, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 111
    .line 112
    .line 113
    throw p0
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/util/concurrent/ExecutionException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/util/concurrent/TimeoutException; {:try_start_0 .. :try_end_0} :catch_0

    .line 114
    :catch_0
    return-void

    .line 115
    :catch_1
    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    .line 116
    .line 117
    .line 118
    move-result-object p0

    .line 119
    invoke-virtual {p0}, Ljava/lang/Thread;->interrupt()V

    .line 120
    .line 121
    .line 122
    return-void
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
.end method

.method public final b(Lcpt;Lcqr;)Lcxu;
    .locals 2

    .line 1
    iget-object v0, p0, Lcsg;->h:Lcsj;

    .line 2
    .line 3
    new-instance v1, Lcqx;

    .line 4
    .line 5
    invoke-direct {v1, p0, p1, v0, p2}, Lcqx;-><init>(Lcqy;Lcpt;Lcsj;Lcqr;)V

    .line 6
    .line 7
    .line 8
    const/4 p1, 0x2

    .line 9
    invoke-super {p0, p1, v1}, Lcsg;->f(ILcsz;)V

    .line 10
    .line 11
    .line 12
    new-instance p0, Lcvd;

    .line 13
    .line 14
    invoke-direct {p0}, Lcvd;-><init>()V

    .line 15
    .line 16
    .line 17
    invoke-static {v1, p0}, Lcma;->t(Lcsl;Lcve;)Lcxu;

    .line 18
    .line 19
    .line 20
    move-result-object p0

    .line 21
    return-object p0
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
.end method

.method public final c(Lcom/google/android/gms/clearcut/internal/BatchedLogErrorParcelable;)V
    .locals 3

    .line 1
    iget-object v0, p1, Lcom/google/android/gms/clearcut/internal/BatchedLogErrorParcelable;->a:Ljava/util/List;

    .line 2
    .line 3
    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    if-eqz v0, :cond_0

    .line 8
    .line 9
    sget-object p0, Lcom/google/android/gms/common/api/Status;->a:Lcom/google/android/gms/common/api/Status;

    .line 10
    .line 11
    invoke-static {p0}, Lcvv;->ab(Ljava/lang/Object;)Lcxu;

    .line 12
    .line 13
    .line 14
    return-void

    .line 15
    :cond_0
    new-instance v0, Lcty;

    .line 16
    .line 17
    invoke-direct {v0}, Lcty;-><init>()V

    .line 18
    .line 19
    .line 20
    new-instance v1, Lcvl;

    .line 21
    .line 22
    const/4 v2, 0x1

    .line 23
    invoke-direct {v1, p1, v2}, Lcvl;-><init>(Ljava/lang/Object;I)V

    .line 24
    .line 25
    .line 26
    iput-object v1, v0, Lcty;->a:Lctv;

    .line 27
    .line 28
    new-array p1, v2, [Lcom/google/android/gms/common/Feature;

    .line 29
    .line 30
    const/4 v1, 0x0

    .line 31
    sget-object v2, Lcqp;->a:Lcom/google/android/gms/common/Feature;

    .line 32
    .line 33
    aput-object v2, p1, v1

    .line 34
    .line 35
    iput-object p1, v0, Lcty;->b:[Lcom/google/android/gms/common/Feature;

    .line 36
    .line 37
    invoke-virtual {v0}, Lcty;->b()V

    .line 38
    .line 39
    .line 40
    invoke-virtual {v0}, Lcty;->a()Lctz;

    .line 41
    .line 42
    .line 43
    move-result-object p1

    .line 44
    invoke-virtual {p0, p1}, Lcsg;->i(Lctz;)V

    .line 45
    .line 46
    .line 47
    return-void
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
.end method
