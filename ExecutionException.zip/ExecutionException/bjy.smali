.class public final Lbjy;
.super Ljava/lang/Object;
.source "PG"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field private final synthetic a:I

.field private final b:Ljava/lang/Object;

.field private final c:Ljava/lang/Object;


# direct methods
.method public constructor <init>(Lbph;Ljava/lang/Runnable;I)V
    .locals 0

    .line 1
    iput p3, p0, Lbjy;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lbjy;->b:Ljava/lang/Object;

    iput-object p2, p0, Lbjy;->c:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Lbpp;Lbnu;I)V
    .locals 0

    .line 2
    iput p3, p0, Lbjy;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lbjy;->c:Ljava/lang/Object;

    iput-object p2, p0, Lbjy;->b:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Lfcy;Lfwy;I)V
    .locals 0

    .line 3
    iput p3, p0, Lbjy;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lbjy;->b:Ljava/lang/Object;

    iput-object p2, p0, Lbjy;->c:Ljava/lang/Object;

    return-void
.end method

.method public constructor <init>(Lfxn;Lfwy;I)V
    .locals 0

    .line 4
    iput p3, p0, Lbjy;->a:I

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lbjy;->c:Ljava/lang/Object;

    iput-object p2, p0, Lbjy;->b:Ljava/lang/Object;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 4

    .line 1
    iget v0, p0, Lbjy;->a:I

    .line 2
    .line 3
    if-eqz v0, :cond_8

    .line 4
    .line 5
    const/4 v1, 0x1

    .line 6
    if-eq v0, v1, :cond_6

    .line 7
    .line 8
    const/4 v1, 0x2

    .line 9
    if-eq v0, v1, :cond_5

    .line 10
    .line 11
    const/4 v1, 0x3

    .line 12
    if-eq v0, v1, :cond_2

    .line 13
    .line 14
    const/4 v1, 0x4

    .line 15
    if-eq v0, v1, :cond_1

    .line 16
    .line 17
    iget-object v0, p0, Lbjy;->b:Ljava/lang/Object;

    .line 18
    .line 19
    invoke-interface {v0}, Lfcy;->isCancelled()Z

    .line 20
    .line 21
    .line 22
    move-result v1

    .line 23
    if-eqz v1, :cond_0

    .line 24
    .line 25
    iget-object p0, p0, Lbjy;->c:Ljava/lang/Object;

    .line 26
    .line 27
    invoke-static {p0}, Lfuu;->h(Lfwy;)V

    .line 28
    .line 29
    .line 30
    return-void

    .line 31
    :cond_0
    :try_start_0
    iget-object v1, p0, Lbjy;->c:Ljava/lang/Object;

    .line 32
    .line 33
    invoke-static {v0}, La;->f(Ljava/util/concurrent/Future;)Ljava/lang/Object;

    .line 34
    .line 35
    .line 36
    move-result-object v0

    .line 37
    invoke-interface {v1, v0}, Lfrz;->ce(Ljava/lang/Object;)V
    :try_end_0
    .catch Ljava/util/concurrent/ExecutionException; {:try_start_0 .. :try_end_0} :catch_0

    .line 38
    .line 39
    .line 40
    return-void

    .line 41
    :catch_0
    move-exception v0

    .line 42
    iget-object p0, p0, Lbjy;->c:Ljava/lang/Object;

    .line 43
    .line 44
    invoke-static {v0}, Lfuu;->v(Ljava/util/concurrent/ExecutionException;)Ljava/lang/Throwable;

    .line 45
    .line 46
    .line 47
    move-result-object v0

    .line 48
    invoke-static {v0}, Lcma;->bC(Ljava/lang/Throwable;)Ljava/lang/Object;

    .line 49
    .line 50
    .line 51
    move-result-object v0

    .line 52
    invoke-interface {p0, v0}, Lfrz;->ce(Ljava/lang/Object;)V

    .line 53
    .line 54
    .line 55
    return-void

    .line 56
    :cond_1
    iget-object v0, p0, Lbjy;->b:Ljava/lang/Object;

    .line 57
    .line 58
    iget-object p0, p0, Lbjy;->c:Ljava/lang/Object;

    .line 59
    .line 60
    sget-object v1, Lfqj;->a:Lfqj;

    .line 61
    .line 62
    check-cast p0, Lfxn;

    .line 63
    .line 64
    invoke-interface {v0, p0, v1}, Lfwy;->c(Lfxn;Ljava/lang/Object;)V

    .line 65
    .line 66
    .line 67
    return-void

    .line 68
    :cond_2
    iget-object v0, p0, Lbjy;->c:Ljava/lang/Object;

    .line 69
    .line 70
    move-object v1, v0

    .line 71
    check-cast v1, Lbpp;

    .line 72
    .line 73
    iget-object v1, v1, Lbpp;->d:Ljava/lang/Object;

    .line 74
    .line 75
    monitor-enter v1

    .line 76
    :try_start_1
    move-object v2, v0

    .line 77
    check-cast v2, Lbpp;

    .line 78
    .line 79
    iget-object v2, v2, Lbpp;->b:Ljava/util/Map;

    .line 80
    .line 81
    iget-object p0, p0, Lbjy;->b:Ljava/lang/Object;

    .line 82
    .line 83
    invoke-interface {v2, p0}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 84
    .line 85
    .line 86
    move-result-object v2

    .line 87
    check-cast v2, Lbjy;

    .line 88
    .line 89
    if-eqz v2, :cond_3

    .line 90
    .line 91
    check-cast v0, Lbpp;

    .line 92
    .line 93
    iget-object v0, v0, Lbpp;->c:Ljava/util/Map;

    .line 94
    .line 95
    invoke-interface {v0, p0}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 96
    .line 97
    .line 98
    move-result-object v0

    .line 99
    check-cast v0, Lbpo;

    .line 100
    .line 101
    if-eqz v0, :cond_4

    .line 102
    .line 103
    check-cast p0, Lbnu;

    .line 104
    .line 105
    invoke-interface {v0, p0}, Lbpo;->b(Lbnu;)V

    .line 106
    .line 107
    .line 108
    goto :goto_0

    .line 109
    :cond_3
    invoke-static {}, Lbiu;->a()Lbiu;

    .line 110
    .line 111
    .line 112
    move-result-object v0

    .line 113
    const-string v2, "WrkTimerRunnable"

    .line 114
    .line 115
    const-string v3, "Timer with %s is already marked as complete."

    .line 116
    .line 117
    filled-new-array {p0}, [Ljava/lang/Object;

    .line 118
    .line 119
    .line 120
    move-result-object p0

    .line 121
    invoke-static {v3, p0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    .line 122
    .line 123
    .line 124
    move-result-object p0

    .line 125
    invoke-virtual {v0, v2, p0}, Lbiu;->c(Ljava/lang/String;Ljava/lang/String;)V

    .line 126
    .line 127
    .line 128
    :cond_4
    :goto_0
    monitor-exit v1

    .line 129
    return-void

    .line 130
    :catchall_0
    move-exception p0

    .line 131
    monitor-exit v1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    .line 132
    throw p0

    .line 133
    :cond_5
    :try_start_2
    iget-object v0, p0, Lbjy;->c:Ljava/lang/Object;

    .line 134
    .line 135
    invoke-interface {v0}, Ljava/lang/Runnable;->run()V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_2

    .line 136
    .line 137
    .line 138
    iget-object p0, p0, Lbjy;->b:Ljava/lang/Object;

    .line 139
    .line 140
    move-object v0, p0

    .line 141
    check-cast v0, Lbph;

    .line 142
    .line 143
    iget-object v0, v0, Lbph;->a:Ljava/lang/Object;

    .line 144
    .line 145
    monitor-enter v0

    .line 146
    :try_start_3
    check-cast p0, Lbph;

    .line 147
    .line 148
    invoke-virtual {p0}, Lbph;->a()V

    .line 149
    .line 150
    .line 151
    monitor-exit v0

    .line 152
    return-void

    .line 153
    :catchall_1
    move-exception p0

    .line 154
    monitor-exit v0
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    .line 155
    throw p0

    .line 156
    :catchall_2
    move-exception v0

    .line 157
    iget-object p0, p0, Lbjy;->b:Ljava/lang/Object;

    .line 158
    .line 159
    move-object v1, p0

    .line 160
    check-cast v1, Lbph;

    .line 161
    .line 162
    iget-object v1, v1, Lbph;->a:Ljava/lang/Object;

    .line 163
    .line 164
    monitor-enter v1

    .line 165
    :try_start_4
    check-cast p0, Lbph;

    .line 166
    .line 167
    invoke-virtual {p0}, Lbph;->a()V

    .line 168
    .line 169
    .line 170
    monitor-exit v1
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_3

    .line 171
    throw v0

    .line 172
    :catchall_3
    move-exception p0

    .line 173
    :try_start_5
    monitor-exit v1
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_3

    .line 174
    throw p0

    .line 175
    :cond_6
    iget-object v0, p0, Lbjy;->b:Ljava/lang/Object;

    .line 176
    .line 177
    invoke-interface {v0}, Lfcy;->isCancelled()Z

    .line 178
    .line 179
    .line 180
    move-result v1

    .line 181
    if-eqz v1, :cond_7

    .line 182
    .line 183
    iget-object p0, p0, Lbjy;->c:Ljava/lang/Object;

    .line 184
    .line 185
    invoke-static {p0}, Lfuu;->h(Lfwy;)V

    .line 186
    .line 187
    .line 188
    return-void

    .line 189
    :cond_7
    :try_start_6
    iget-object v1, p0, Lbjy;->c:Ljava/lang/Object;

    .line 190
    .line 191
    sget v2, Lpg;->c:I

    .line 192
    .line 193
    invoke-static {v0}, La;->f(Ljava/util/concurrent/Future;)Ljava/lang/Object;

    .line 194
    .line 195
    .line 196
    move-result-object v0

    .line 197
    invoke-interface {v1, v0}, Lfwy;->ce(Ljava/lang/Object;)V
    :try_end_6
    .catch Ljava/util/concurrent/ExecutionException; {:try_start_6 .. :try_end_6} :catch_1

    .line 198
    .line 199
    .line 200
    return-void

    .line 201
    :catch_1
    move-exception v0

    .line 202
    iget-object p0, p0, Lbjy;->c:Ljava/lang/Object;

    .line 203
    .line 204
    invoke-static {v0}, Llr;->j(Ljava/util/concurrent/ExecutionException;)Ljava/lang/Throwable;

    .line 205
    .line 206
    .line 207
    move-result-object v0

    .line 208
    invoke-static {v0}, Lcma;->bC(Ljava/lang/Throwable;)Ljava/lang/Object;

    .line 209
    .line 210
    .line 211
    move-result-object v0

    .line 212
    invoke-interface {p0, v0}, Lfrz;->ce(Ljava/lang/Object;)V

    .line 213
    .line 214
    .line 215
    return-void

    .line 216
    :cond_8
    iget-object v0, p0, Lbjy;->b:Ljava/lang/Object;

    .line 217
    .line 218
    invoke-interface {v0}, Lfcy;->isCancelled()Z

    .line 219
    .line 220
    .line 221
    move-result v1

    .line 222
    if-eqz v1, :cond_9

    .line 223
    .line 224
    iget-object p0, p0, Lbjy;->c:Ljava/lang/Object;

    .line 225
    .line 226
    invoke-static {p0}, Lfuu;->h(Lfwy;)V

    .line 227
    .line 228
    .line 229
    return-void

    .line 230
    :cond_9
    :try_start_7
    iget-object v1, p0, Lbjy;->c:Ljava/lang/Object;

    .line 231
    .line 232
    invoke-static {v0}, Lbld;->a(Ljava/util/concurrent/Future;)Ljava/lang/Object;

    .line 233
    .line 234
    .line 235
    move-result-object v0

    .line 236
    invoke-interface {v1, v0}, Lfwy;->ce(Ljava/lang/Object;)V
    :try_end_7
    .catch Ljava/util/concurrent/ExecutionException; {:try_start_7 .. :try_end_7} :catch_2

    .line 237
    .line 238
    .line 239
    return-void

    .line 240
    :catch_2
    move-exception v0

    .line 241
    iget-object p0, p0, Lbjy;->c:Ljava/lang/Object;

    .line 242
    .line 243
    invoke-static {v0}, Lbld;->b(Ljava/util/concurrent/ExecutionException;)Ljava/lang/Throwable;

    .line 244
    .line 245
    .line 246
    move-result-object v0

    .line 247
    invoke-static {v0}, Lcma;->bC(Ljava/lang/Throwable;)Ljava/lang/Object;

    .line 248
    .line 249
    .line 250
    move-result-object v0

    .line 251
    invoke-interface {p0, v0}, Lfrz;->ce(Ljava/lang/Object;)V

    .line 252
    .line 253
    .line 254
    return-void
    .line 255
    .line 256
    .line 257
    .line 258
    .line 259
    .line 260
    .line 261
    .line 262
    .line 263
    .line 264
    .line 265
    .line 266
    .line 267
    .line 268
    .line 269
    .line 270
    .line 271
    .line 272
    .line 273
    .line 274
    .line 275
    .line 276
    .line 277
    .line 278
    .line 279
    .line 280
    .line 281
    .line 282
    .line 283
    .line 284
    .line 285
    .line 286
    .line 287
    .line 288
    .line 289
    .line 290
    .line 291
    .line 292
    .line 293
    .line 294
    .line 295
    .line 296
    .line 297
    .line 298
    .line 299
    .line 300
    .line 301
    .line 302
    .line 303
    .line 304
    .line 305
    .line 306
    .line 307
    .line 308
    .line 309
    .line 310
    .line 311
    .line 312
    .line 313
    .line 314
    .line 315
    .line 316
    .line 317
    .line 318
    .line 319
    .line 320
    .line 321
    .line 322
    .line 323
    .line 324
    .line 325
    .line 326
    .line 327
    .line 328
    .line 329
    .line 330
    .line 331
    .line 332
    .line 333
    .line 334
    .line 335
    .line 336
    .line 337
    .line 338
    .line 339
    .line 340
    .line 341
    .line 342
    .line 343
    .line 344
    .line 345
    .line 346
    .line 347
    .line 348
    .line 349
    .line 350
    .line 351
    .line 352
    .line 353
    .line 354
    .line 355
    .line 356
    .line 357
    .line 358
    .line 359
    .line 360
    .line 361
    .line 362
    .line 363
    .line 364
    .line 365
    .line 366
    .line 367
    .line 368
    .line 369
    .line 370
    .line 371
    .line 372
    .line 373
    .line 374
    .line 375
    .line 376
    .line 377
    .line 378
    .line 379
    .line 380
    .line 381
    .line 382
    .line 383
    .line 384
    .line 385
    .line 386
    .line 387
    .line 388
    .line 389
    .line 390
    .line 391
    .line 392
    .line 393
    .line 394
    .line 395
    .line 396
    .line 397
    .line 398
    .line 399
    .line 400
    .line 401
    .line 402
    .line 403
    .line 404
    .line 405
    .line 406
    .line 407
    .line 408
    .line 409
    .line 410
    .line 411
    .line 412
    .line 413
    .line 414
    .line 415
    .line 416
    .line 417
    .line 418
    .line 419
    .line 420
    .line 421
    .line 422
    .line 423
    .line 424
    .line 425
    .line 426
    .line 427
    .line 428
    .line 429
    .line 430
    .line 431
    .line 432
    .line 433
    .line 434
    .line 435
    .line 436
    .line 437
    .line 438
    .line 439
    .line 440
    .line 441
    .line 442
    .line 443
    .line 444
    .line 445
    .line 446
    .line 447
    .line 448
    .line 449
    .line 450
    .line 451
    .line 452
    .line 453
    .line 454
    .line 455
    .line 456
    .line 457
    .line 458
    .line 459
    .line 460
    .line 461
    .line 462
    .line 463
    .line 464
    .line 465
    .line 466
    .line 467
    .line 468
    .line 469
    .line 470
    .line 471
    .line 472
    .line 473
    .line 474
    .line 475
    .line 476
    .line 477
    .line 478
    .line 479
    .line 480
    .line 481
    .line 482
    .line 483
    .line 484
    .line 485
    .line 486
    .line 487
    .line 488
    .line 489
    .line 490
    .line 491
    .line 492
    .line 493
    .line 494
    .line 495
    .line 496
    .line 497
    .line 498
    .line 499
    .line 500
    .line 501
    .line 502
    .line 503
    .line 504
    .line 505
    .line 506
    .line 507
    .line 508
    .line 509
    .line 510
    .line 511
    .line 512
    .line 513
    .line 514
    .line 515
    .line 516
    .line 517
    .line 518
    .line 519
    .line 520
    .line 521
    .line 522
    .line 523
    .line 524
    .line 525
    .line 526
    .line 527
    .line 528
    .line 529
    .line 530
    .line 531
    .line 532
    .line 533
    .line 534
    .line 535
    .line 536
    .line 537
    .line 538
    .line 539
    .line 540
    .line 541
    .line 542
    .line 543
    .line 544
    .line 545
    .line 546
    .line 547
    .line 548
    .line 549
    .line 550
    .line 551
    .line 552
    .line 553
    .line 554
    .line 555
    .line 556
    .line 557
    .line 558
    .line 559
    .line 560
    .line 561
    .line 562
    .line 563
    .line 564
    .line 565
    .line 566
    .line 567
    .line 568
    .line 569
    .line 570
    .line 571
    .line 572
    .line 573
    .line 574
    .line 575
    .line 576
    .line 577
    .line 578
    .line 579
    .line 580
    .line 581
    .line 582
    .line 583
    .line 584
    .line 585
    .line 586
    .line 587
    .line 588
    .line 589
    .line 590
    .line 591
    .line 592
    .line 593
    .line 594
    .line 595
    .line 596
    .line 597
    .line 598
    .line 599
    .line 600
    .line 601
    .line 602
    .line 603
    .line 604
    .line 605
    .line 606
    .line 607
    .line 608
    .line 609
    .line 610
    .line 611
    .line 612
    .line 613
    .line 614
    .line 615
    .line 616
    .line 617
    .line 618
    .line 619
    .line 620
    .line 621
    .line 622
    .line 623
    .line 624
    .line 625
    .line 626
    .line 627
    .line 628
    .line 629
    .line 630
    .line 631
    .line 632
    .line 633
    .line 634
    .line 635
    .line 636
    .line 637
    .line 638
    .line 639
    .line 640
    .line 641
    .line 642
    .line 643
    .line 644
    .line 645
    .line 646
    .line 647
    .line 648
    .line 649
    .line 650
    .line 651
    .line 652
    .line 653
    .line 654
    .line 655
    .line 656
.end method
